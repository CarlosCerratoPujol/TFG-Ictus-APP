package com.example.ictusapp.ui.screens.neuro

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.NavHostController
import com.example.ictusapp.data.AuthRepository
import com.example.ictusapp.data.CaseRepository
import com.example.ictusapp.ui.components.NeuroLayout
import com.example.ictusapp.ui.navigation.Routes

@Composable
fun NeuroUC1EligibilityScreen(navController: NavHostController, caseId: String) {

    val repo = CaseRepository()
    val auth = AuthRepository()

    var eligible by remember { mutableStateOf(true) }
    var reason by remember { mutableStateOf("") }
    var plan by remember { mutableStateOf("") }
    var notes by remember { mutableStateOf("") }

    var loading by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }

    NeuroLayout(
        title = "UC1 — Elegibilidad trombólisis",
        navController = navController,
        currentRoute = Routes.NeuroHome
    ) { modifier ->

        Column(
            modifier = modifier
                .fillMaxSize()
                .padding(16.dp)
        ) {

            // 🟦 TARJETA DECISIÓN
            Card(
                elevation = CardDefaults.cardElevation(6.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(Modifier.padding(16.dp)) {

                    Text("🧠 Decisión clínica", style = MaterialTheme.typography.titleMedium)

                    Spacer(Modifier.height(12.dp))

                    Text("¿Paciente elegible para trombólisis?")

                    Spacer(Modifier.height(12.dp))

                    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {

                        FilterChip(
                            selected = eligible,
                            onClick = { eligible = true },
                            label = { Text("🟢 SÍ") }
                        )

                        FilterChip(
                            selected = !eligible,
                            onClick = { eligible = false },
                            label = { Text("🔴 NO") }
                        )
                    }
                }
            }

            Spacer(Modifier.height(16.dp))

            // 🟦 MOTIVO + PLAN (solo si NO)
            if (!eligible) {
                Card(
                    elevation = CardDefaults.cardElevation(6.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(Modifier.padding(16.dp)) {

                        Text("⚠️ Motivo y plan alternativo", style = MaterialTheme.typography.titleMedium)

                        Spacer(Modifier.height(12.dp))

                        OutlinedTextField(
                            value = reason,
                            onValueChange = { reason = it },
                            label = { Text("Motivo de exclusión") },
                            modifier = Modifier.fillMaxWidth()
                        )

                        Spacer(Modifier.height(8.dp))

                        OutlinedTextField(
                            value = plan,
                            onValueChange = { plan = it },
                            label = { Text("Plan alternativo") },
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                }

                Spacer(Modifier.height(16.dp))
            }

            // 🟦 NOTAS
            Card(
                elevation = CardDefaults.cardElevation(6.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(Modifier.padding(16.dp)) {

                    Text("📝 Notas clínicas", style = MaterialTheme.typography.titleMedium)

                    Spacer(Modifier.height(12.dp))

                    OutlinedTextField(
                        value = notes,
                        onValueChange = { notes = it },
                        label = { Text("Observaciones") },
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }

            Spacer(Modifier.height(16.dp))

            // ❌ ERROR
            error?.let {
                Text(it, color = MaterialTheme.colorScheme.error)
            }

            Spacer(Modifier.height(16.dp))

            // 🚀 BOTÓN
            Button(
                onClick = {

                    if (!eligible) {
                        if (reason.isBlank()) {
                            error = "Indica el motivo de exclusión"
                            return@Button
                        }
                        if (plan.isBlank()) {
                            error = "Indica el plan alternativo"
                            return@Button
                        }
                    }

                    loading = true
                    error = null

                    repo.completeTask(
                        caseId = caseId,
                        taskCode = "UC1",
                        data = mapOf(
                            "eligible" to eligible,
                            "cancelReason" to if (!eligible) reason.trim() else "",
                            "alternativePlan" to if (!eligible) plan.trim() else "",
                            "notes" to notes.trim()
                        ),
                        onOk = {

                            if (!eligible) {
                                repo.closeCaseNotEligible(
                                    caseId = caseId,
                                    cancelReason = reason,
                                    alternativePlan = plan,
                                    closedByEmail = auth.currentEmail() ?: "unknown",
                                    onOk = {
                                        loading = false
                                        navController.navigate(Routes.NeuroHome) {
                                            popUpTo(Routes.NeuroHome) { inclusive = true }
                                        }
                                    },
                                    onErr = {
                                        loading = false
                                        error = it
                                    }
                                )
                            } else {
                                loading = false
                                navController.popBackStack()
                            }
                        },
                        onErr = {
                            loading = false
                            error = it
                        }
                    )
                },
                enabled = !loading,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(if (loading) "Guardando..." else "Confirmar decisión clínica")
            }
        }
    }
}