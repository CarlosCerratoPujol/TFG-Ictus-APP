package com.example.ictusapp.ui.screens.nursing

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.NavHostController
import com.example.ictusapp.data.CaseRepository
import com.example.ictusapp.ui.components.NursingLayout
import com.example.ictusapp.ui.navigation.Routes

@Composable
fun NursingUC78AdministrationScreen(navController: NavHostController, caseId: String) {

    val repo = CaseRepository()

    var bolusGivenMg by remember { mutableStateOf("") }
    var infusionStarted by remember { mutableStateOf(true) }
    var notes by remember { mutableStateOf("") }

    var loading by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }

    NursingLayout(
        title = "UC7+UC8 — Administración",
        navController = navController,
        currentRoute = Routes.NursingHome
    ) { modifier ->

        Column(
            modifier = modifier
                .fillMaxSize()
                .padding(16.dp)
        ) {

            // 🟦 ADMINISTRACIÓN BOLO
            Card(modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp)) {

                    Text("💉 Bolo de alteplasa", style = MaterialTheme.typography.titleMedium)

                    Spacer(Modifier.height(12.dp))

                    OutlinedTextField(
                        value = bolusGivenMg,
                        onValueChange = { bolusGivenMg = it },
                        label = { Text("Cantidad administrada (mg)") },
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }

            Spacer(Modifier.height(16.dp))

            // 🟦 PERFUSIÓN
            Card(modifier = Modifier.fillMaxWidth()) {
                Row(
                    Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("Perfusión iniciada")
                    Switch(
                        checked = infusionStarted,
                        onCheckedChange = { infusionStarted = it }
                    )
                }
            }

            Spacer(Modifier.height(16.dp))

            // 🟦 NOTAS
            Card(modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp)) {

                    Text("📝 Observaciones", style = MaterialTheme.typography.titleMedium)

                    Spacer(Modifier.height(12.dp))

                    OutlinedTextField(
                        value = notes,
                        onValueChange = { notes = it },
                        label = { Text("Notas clínicas") },
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }

            Spacer(Modifier.height(16.dp))

            // ❌ ERROR
            error?.let {
                Text(it, color = MaterialTheme.colorScheme.error)
            }

            Spacer(Modifier.height(16.dp))

            // 🚀 BOTÓN
            Button(
                onClick = {

                    val bolo = bolusGivenMg.replace(",", ".").toDoubleOrNull()

                    if (bolo == null || bolo < 0) {
                        error = "Introduce un valor válido de bolo"
                        return@Button
                    }

                    loading = true
                    error = null

                    repo.completeTask(
                        caseId = caseId,
                        taskCode = "UC7_8",
                        data = mapOf(
                            "bolusGivenMg" to bolo,
                            "infusionStarted" to infusionStarted,
                            "notes" to notes.trim()
                        ),
                        onOk = {
                            loading = false
                            navController.popBackStack()
                        },
                        onErr = {
                            loading = false
                            error = it
                        }
                    )
                },
                enabled = !loading,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(if (loading) "Guardando..." else "Confirmar administración")
            }
        }
    }
}
