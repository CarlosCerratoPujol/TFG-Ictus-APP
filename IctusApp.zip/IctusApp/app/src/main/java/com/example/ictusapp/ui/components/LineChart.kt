package com.example.ictusapp.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.*
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp

@Composable
fun LineChart(
    values: List<Float>,
    modifier: Modifier = Modifier,
    lineColor: Color = Color(0xFF5C6BC0),
    labels: List<String> = emptyList()
) {
    if (values.isEmpty()) return

    val max = values.maxOrNull() ?: 1f
    val min = values.minOrNull() ?: 0f
    val range = (max - min).takeIf { it != 0f } ?: 1f

    Column(
        modifier = modifier.fillMaxWidth()
    ) {
        Canvas(
            modifier = Modifier
                .fillMaxWidth()
                .height(220.dp)
        ) {
            if (values.size == 1) {
                val x = size.width / 2f
                val y = size.height / 2f

                drawCircle(
                    color = lineColor,
                    radius = 10f,
                    center = Offset(x, y)
                )
            } else {
                val stepX = size.width / (values.size - 1)

                val points = values.mapIndexed { index, value ->
                    val x = index * stepX
                    val y = size.height - ((value - min) / range * size.height)
                    Offset(x, y)
                }

                for (i in 0 until points.size - 1) {
                    drawLine(
                        color = lineColor,
                        start = points[i],
                        end = points[i + 1],
                        strokeWidth = 6f
                    )
                }

                points.forEach { point ->
                    drawCircle(
                        color = lineColor,
                        radius = 8f,
                        center = point
                    )
                }
            }
        }

        Spacer(Modifier.height(8.dp))

        if (labels.isNotEmpty() && labels.size == values.size) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceEvenly,
                verticalAlignment = Alignment.Top
            ) {
                labels.zip(values).forEach { (label, value) ->
                    Column(
                        modifier = Modifier.weight(1f),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            text = label,
                            style = MaterialTheme.typography.bodySmall,
                            textAlign = TextAlign.Center
                        )
                        Text(
                            text = value.toInt().toString(),
                            style = MaterialTheme.typography.labelSmall,
                            textAlign = TextAlign.Center
                        )
                    }
                }
            }
        }
    }
}