package com.example.ictusapp.ui.screens.common

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.navigation.NavHostController
import com.example.ictusapp.data.CaseRepository
import com.example.ictusapp.data.ClosedCaseDetail
import com.example.ictusapp.ui.components.*
import com.example.ictusapp.ui.navigation.Routes
import java.text.SimpleDateFormat
import java.util.Locale

@Composable
fun ClosedCaseDetailScreen(
    navController: NavHostController,
    caseId: String,
    role: String
) {
    val repo = CaseRepository()
    val context = LocalContext.current

    var detail by remember { mutableStateOf<ClosedCaseDetail?>(null) }
    var error by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(caseId) {
        repo.getClosedCaseDetail(
            caseId = caseId,
            onOk = { detail = it },
            onErr = { error = it }
        )
    }

    fun fmt(ts: com.google.firebase.Timestamp?): String {
        if (ts == null) return "-"
        val df = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault())
        return df.format(ts.toDate())
    }

    val content: @Composable (Modifier) -> Unit = { modifier ->

        val d = detail

        // 🔥 LOADING / ERROR
        if (d == null) {
            Column(
                modifier = modifier
                    .fillMaxSize()
                    .padding(16.dp)
            ) {
                error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
                Text("Cargando…")
            }
        } else {

            val tasks = d.tasksSnapshot.orEmpty()

            LazyColumn(
                modifier = modifier.fillMaxSize(),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {

                item {
                    error?.let {
                        Text(it, color = MaterialTheme.colorScheme.error)
                    }
                }

                // =========================
                // 🏥 ADMISIÓN
                // =========================
                if (role == "ADMISSION") {
                    item {
                        Card {
                            Column(Modifier.padding(16.dp)) {
                                Text("🧑 Paciente", style = MaterialTheme.typography.titleMedium)
                                Spacer(Modifier.height(8.dp))
                                Text("Nombre: ${d.patientName}")
                                Text("ID: ${d.patientId}")
                                Text("Llegada: ${fmt(d.arrivalAt)}")
                                Text("Destino: ${d.destination}")
                                Text("Cierre: ${fmt(d.closedAt)}")
                            }
                        }
                    }
                }

                // =========================
                // 🧠 NEURO
                // =========================
                if (role == "NEURO") {

                    item {
                        Card {
                            Column(Modifier.padding(16.dp)) {
                                Text("🧠 Resumen clínico")

                                val eligTxt = when (d.uc1Eligible) {
                                    true -> "🟢 Sí"
                                    false -> "🔴 No"
                                    null -> "-"
                                }

                                Text("Elegible: $eligTxt")

                                if (d.uc5TotalDoseMg != null) {
                                    Text("Dosis total: ${d.uc5TotalDoseMg} mg")
                                }
                            }
                        }
                    }

                    // 📈 NIHSS
                    val nihssValues = d.logs.mapNotNull {
                        Regex("""NIHSS[:=]\s*(\d+)""")
                            .find(it.message)
                            ?.groupValues?.getOrNull(1)?.toFloatOrNull()
                    }

                    if (nihssValues.isNotEmpty()) {
                        item {
                            Card {
                                Column(Modifier.padding(16.dp)) {
                                    Text("📈 Evolución NIHSS")
                                    LineChart(values = nihssValues)
                                }
                            }
                        }
                    }

                    // 💉 DOSIS
                    val uc5Task = tasks.firstOrNull {
                        it["code"]?.toString() == "UC5"
                    }

                    val uc5Data = uc5Task?.get("data") as? Map<String, Any>

                    val total = (uc5Data?.get("totalDoseMg") as? Number)?.toFloat() ?: 0f
                    val bolus = (uc5Data?.get("bolusDoseMg") as? Number)?.toFloat() ?: 0f
                    val infusion = (uc5Data?.get("infusionDoseMg") as? Number)?.toFloat() ?: 0f

                    if (total > 0f || bolus > 0f || infusion > 0f) {
                        item {
                            Card {
                                Column(Modifier.padding(16.dp)) {
                                    Text("💉 Dosis")
                                    Text("Total: $total")
                                    Text("Bolo: $bolus")
                                    Text("Perfusión: $infusion")

                                    BarChart(
                                        values = listOf(
                                            "Total" to total,
                                            "Bolo" to bolus,
                                            "Perfusión" to infusion
                                        )
                                    )
                                }
                            }
                        }
                    }
                }

                // =========================
                // 💉 ENFERMERÍA
                // =========================
                if (role == "NURSING") {

                    item {
                        Card {
                            Column(Modifier.padding(16.dp)) {
                                Text("📄 Registro")

                                d.logs.forEach {
                                    Text("• ${fmt(it.at)} — ${it.message}")
                                }
                            }
                        }
                    }

                    val vitalsTask = tasks.firstOrNull {
                        it["code"]?.toString() == "UC3_4"
                    }

                    val data = vitalsTask?.get("data") as? Map<String, Any>

                    val sbp = (data?.get("sbp") as? Number)?.toFloat() ?: 0f
                    val dbp = (data?.get("dbp") as? Number)?.toFloat() ?: 0f
                    val glucose = (data?.get("glucose") as? Number)?.toFloat() ?: 0f

                    if (sbp > 0f || dbp > 0f || glucose > 0f) {
                        item {
                            Card {
                                Column(Modifier.padding(16.dp)) {
                                    Text("📊 Constantes")
                                    Text("SBP: $sbp")
                                    Text("DBP: $dbp")
                                    Text("GLU: $glucose")

                                    BarChart(
                                        values = listOf(
                                            "SBP" to sbp,
                                            "DBP" to dbp,
                                            "GLU" to glucose
                                        )
                                    )
                                }
                            }
                        }
                    }

                    // 📡 HL7
                    item {
                        Card {
                            Column(Modifier.padding(16.dp)) {

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text("HL7")

                                    TextButton(
                                        onClick = {
                                            val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                            val clip = ClipData.newPlainText("HL7", d.hl7 ?: "")
                                            clipboard.setPrimaryClip(clip)
                                        }
                                    ) {
                                        Text("Copiar")
                                    }
                                }

                                Text(d.hl7 ?: "No disponible")
                            }
                        }
                    }
                }
            }
        }
    }

    when (role) {
        "ADMISSION" -> AdmissionLayout("Detalle", navController, Routes.ClosedCasesAdmission, content)
        "NEURO" -> NeuroLayout("Detalle", navController, Routes.ClosedCasesNeuro, content)
        "NURSING" -> NursingLayout("Detalle", navController, Routes.ClosedCasesNursing, content)
    }
}