package com.example.ictusapp.ui.screens.nursing

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.NavHostController
import com.example.ictusapp.data.AuthRepository
import com.example.ictusapp.data.CaseRepository
import com.example.ictusapp.ui.components.NursingLayout
import com.example.ictusapp.ui.navigation.Routes

@Composable
fun NursingUC6DoubleCheckScreen(navController: NavHostController, caseId: String) {

    val repo = CaseRepository()
    val auth = AuthRepository()

    var idVerified by remember { mutableStateOf(false) }
    var doseVerified by remember { mutableStateOf(false) }
    var notes by remember { mutableStateOf("") }

    var loading by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }

    NursingLayout(
        title = "UC6 — Doble verificación",
        navController = navController,
        currentRoute = Routes.NursingHome
    ) { modifier ->

        Column(
            modifier = modifier
                .fillMaxSize()
                .padding(16.dp)
        ) {

            // 🟦 TARJETA SEGURIDAD
            Card(
                elevation = CardDefaults.cardElevation(6.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(Modifier.padding(16.dp)) {

                    Text("🛡️ Verificación de seguridad", style = MaterialTheme.typography.titleMedium)

                    Spacer(Modifier.height(12.dp))

                    Row(
                        Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("Identidad del paciente")
                        Switch(
                            checked = idVerified,
                            onCheckedChange = { idVerified = it }
                        )
                    }

                    Spacer(Modifier.height(8.dp))

                    Row(
                        Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("Dosis correcta")
                        Switch(
                            checked = doseVerified,
                            onCheckedChange = { doseVerified = it }
                        )
                    }
                }
            }

            Spacer(Modifier.height(16.dp))

            // 🟦 NOTAS
            Card(
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(Modifier.padding(16.dp)) {

                    Text("📝 Incidencias", style = MaterialTheme.typography.titleMedium)

                    Spacer(Modifier.height(12.dp))

                    OutlinedTextField(
                        value = notes,
                        onValueChange = { notes = it },
                        label = { Text("Observaciones") },
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }

            Spacer(Modifier.height(16.dp))

            // ❌ ERROR
            error?.let {
                Text(it, color = MaterialTheme.colorScheme.error)
            }

            Spacer(Modifier.height(16.dp))

            // 🚀 BOTÓN
            Button(
                onClick = {

                    if (!idVerified || !doseVerified) {
                        error = "Debes verificar identidad y dosis"
                        return@Button
                    }

                    loading = true
                    error = null

                    repo.completeTask(
                        caseId = caseId,
                        taskCode = "UC6",
                        data = mapOf(
                            "patientIdVerified" to idVerified,
                            "doseVerified" to doseVerified,
                            "verifiedBy" to (auth.currentEmail() ?: "unknown"),
                            "discrepancyNotes" to notes.trim()
                        ),
                        onOk = {
                            loading = false
                            navController.popBackStack()
                        },
                        onErr = {
                            loading = false
                            error = it
                        }
                    )
                },
                enabled = !loading,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(if (loading) "Guardando..." else "Confirmar verificación")
            }
        }
    }
}