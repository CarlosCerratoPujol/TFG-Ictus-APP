package com.example.ictusapp.ui.screens.admission

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.NavHostController
import com.example.ictusapp.data.CaseItem
import com.example.ictusapp.data.CaseRepository
import com.example.ictusapp.ui.components.AdmissionLayout
import com.example.ictusapp.ui.navigation.Routes
import com.google.firebase.firestore.ListenerRegistration
import com.example.ictusapp.ui.screens.common.TurnChip

@Composable
fun AdmissionHomeScreen(navController: NavHostController) {

    val repo = CaseRepository()

    var cases by remember { mutableStateOf<List<CaseItem>>(emptyList()) }
    var error by remember { mutableStateOf<String?>(null) }
    var reg by remember { mutableStateOf<ListenerRegistration?>(null) }

    DisposableEffect(Unit) {
        reg = repo.listenActiveCasesForRole(
            role = CaseRepository.ROLE_ADMISSION,
            onUpdate = { cases = it },
            onErr = { error = it }
        )
        onDispose { reg?.remove() }
    }

    AdmissionLayout(
        title = "Admisión - Casos activos",
        navController = navController,
        currentRoute = Routes.AdmissionHome
    ) { modifier ->

        Box(modifier = modifier.fillMaxSize()) {

            Column {

                // ❌ Error
                error?.let {
                    Text(
                        it,
                        color = MaterialTheme.colorScheme.error,
                        modifier = Modifier.padding(16.dp)
                    )
                }

                // 📋 Lista de casos
                LazyColumn(
                    contentPadding = PaddingValues(16.dp)
                ) {
                    items(items = cases, key = { it.id }) { c ->

                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(bottom = 12.dp),
                            elevation = CardDefaults.cardElevation(4.dp),
                            onClick = {
                                navController.navigate(
                                    Routes.AdmissionCaseTasks + "/${c.id}"
                                )
                            }
                        ) {
                            Column(Modifier.padding(16.dp)) {

                                Text(
                                    text = c.patientName.ifBlank { "Paciente sin nombre" },
                                    style = MaterialTheme.typography.titleMedium
                                )

                                Text(
                                    text = "ID: ${c.patientId}",
                                    style = MaterialTheme.typography.bodyMedium
                                )

                                Spacer(modifier = Modifier.height(8.dp))

                                // 🔁 Turno actual
                                TurnChip(
                                    caseId = c.id,
                                    role = CaseRepository.ROLE_ADMISSION
                                )
                            }
                        }
                    }
                }
            }

            // ➕ Botón flotante (crear caso)
            FloatingActionButton(
                onClick = {
                    navController.navigate(Routes.AdmissionCreateCase)
                },
                modifier = Modifier
                    .align(androidx.compose.ui.Alignment.BottomEnd)
                    .padding(16.dp)
            ) {
                Text("+")
            }
        }
    }
}