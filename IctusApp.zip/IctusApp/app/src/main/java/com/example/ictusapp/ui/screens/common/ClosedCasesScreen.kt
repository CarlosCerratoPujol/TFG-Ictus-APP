package com.example.ictusapp.ui.screens.common

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.NavHostController
import com.example.ictusapp.data.CaseRepository
import com.example.ictusapp.data.ClosedCaseItem
import com.example.ictusapp.ui.components.AdmissionLayout
import com.example.ictusapp.ui.components.BarChart
import com.example.ictusapp.ui.components.LineChart
import com.example.ictusapp.ui.components.NeuroLayout
import com.example.ictusapp.ui.components.NursingLayout
import com.example.ictusapp.ui.navigation.Routes
import com.google.firebase.firestore.ListenerRegistration
import java.text.SimpleDateFormat
import java.util.Locale

@Composable
fun ClosedCasesScreen(
    navController: NavHostController,
    role: String,
) {
    val repo = CaseRepository()

    var cases by remember { mutableStateOf<List<ClosedCaseItem>>(emptyList()) }
    var error by remember { mutableStateOf<String?>(null) }
    var loading by remember { mutableStateOf(true) }
    var reg by remember { mutableStateOf<ListenerRegistration?>(null) }

    DisposableEffect(role) {
        loading = true
        reg = repo.listenClosedCasesForRole(
            role = role,
            onUpdate = {
                cases = it.sortedByDescending { c -> c.closedAt }
                loading = false
            },
            onErr = {
                error = it
                loading = false
            }
        )
        onDispose { reg?.remove() }
    }

    fun fmt(ts: com.google.firebase.Timestamp?): String {
        if (ts == null) return "-"
        val df = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault())
        return df.format(ts.toDate())
    }

    val content: @Composable (Modifier) -> Unit = { modifier ->

        LazyColumn(
            modifier = modifier.fillMaxSize(),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            item {
                error?.let {
                    Text(it, color = MaterialTheme.colorScheme.error)
                }
            }

            if (loading) {
                item { Text("Cargando…") }
                return@LazyColumn
            }

            if (cases.isEmpty()) {
                item { Text("No hay casos cerrados aún.") }
                return@LazyColumn
            }

            val doses = cases.mapNotNull { c ->
                val task = c.tasksSnapshot?.firstOrNull { t ->
                    t["code"]?.toString() == "UC5"
                }
                val data = task?.get("data") as? Map<String, Any>
                (data?.get("totalDoseMg") as? Number)?.toFloat()
            }

            val weights = cases.mapNotNull { c ->
                val task = c.tasksSnapshot?.firstOrNull { t ->
                    t["code"]?.toString() == "UC2"
                }
                val data = task?.get("data") as? Map<String, Any>
                (data?.get("weightKg") as? Number)?.toFloat()
            }

            val avgDose = if (doses.isNotEmpty()) doses.average().toFloat() else 0f
            val avgWeight = if (weights.isNotEmpty()) weights.average().toFloat() else 0f

            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    @Composable
                    fun StatCard(title: String, value: String) {
                        Card(
                            modifier = Modifier.weight(1f),
                            colors = CardDefaults.cardColors(
                                containerColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.10f)
                            )
                        ) {
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(104.dp)
                                    .padding(12.dp),
                                verticalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(
                                    text = title,
                                    style = MaterialTheme.typography.labelMedium
                                )
                                Text(
                                    text = value,
                                    style = MaterialTheme.typography.titleMedium
                                )
                            }
                        }
                    }

                    StatCard("📊 Casos", "${cases.size}")
                    StatCard("💉 Dosis media", "${avgDose.toInt()} mg")
                    StatCard("⚖️ Peso medio", "${avgWeight.toInt()} kg")
                }
            }

            // =========================
            // MÉTRICAS SOLO ADMISIÓN
            // =========================
            if (role == "ADMISSION") {
                val dateStats = cases.groupingBy {
                    val ts = it.closedAt?.toDate()
                    val df = SimpleDateFormat("dd/MM", Locale.getDefault())
                    ts?.let { df.format(it) } ?: "?"
                }.eachCount()

                val dateLabels = dateStats.keys.toList()
                val dateValues = dateStats.values.map { it.toFloat() }

                if (dateValues.isNotEmpty()) {
                    item {
                        Card {
                            Column(Modifier.padding(16.dp)) {
                                Text("📈 Casos por día", style = MaterialTheme.typography.titleMedium)
                                Spacer(Modifier.height(12.dp))
                                LineChart(
                                    values = dateValues,
                                    labels = dateLabels
                                )
                            }
                        }
                    }
                }
            }

            // =========================
            // MÉTRICAS SOLO NEURO
            // =========================
            if (role == "NEURO") {
                val destinationStats = cases.groupingBy {
                    when (it.destination.uppercase()) {
                        "EVENTO ADVERSO" -> "Ev Ad"
                        else -> it.destination.ifBlank { "Sin dato" }
                    }
                }.eachCount()

                val destinationData = destinationStats.map {
                    it.key to it.value.toFloat()
                }

                item {
                    Card {
                        Column(Modifier.padding(16.dp)) {
                            Text("📊 Destinos", style = MaterialTheme.typography.titleMedium)
                            Spacer(Modifier.height(12.dp))
                            BarChart(values = destinationData)
                        }
                    }
                }

                val eligible = cases.mapNotNull { c ->
                    val task = c.tasksSnapshot?.firstOrNull { t ->
                        t["code"]?.toString() == "UC1"
                    }
                    val data = task?.get("data") as? Map<String, Any>
                    data?.get("eligible") as? Boolean
                }

                if (eligible.isNotEmpty()) {
                    val yes = eligible.count { it }
                    val no = eligible.count { !it }

                    item {
                        Card {
                            Column(Modifier.padding(16.dp)) {
                                Text("🧠 Trombólisis", style = MaterialTheme.typography.titleMedium)
                                Spacer(Modifier.height(8.dp))
                                Text("Sí: $yes")
                                Text("No: $no")
                                Spacer(Modifier.height(12.dp))
                                BarChart(
                                    values = listOf(
                                        "Sí" to yes.toFloat(),
                                        "No" to no.toFloat()
                                    )
                                )
                            }
                        }
                    }
                }

                val riskPatients = cases.mapNotNull { c ->
                    val task = c.tasksSnapshot?.firstOrNull { t ->
                        t["code"]?.toString() == "UC3_4"
                    }
                    val data = task?.get("data") as? Map<String, Any>
                    (data?.get("sbp") as? Number)?.toFloat()
                }

                if (riskPatients.isNotEmpty()) {
                    val high = riskPatients.count { it > 180f }
                    val normal = riskPatients.count { it <= 180f }

                    item {
                        Card {
                            Column(Modifier.padding(16.dp)) {
                                Text("🚨 Riesgo pacientes", style = MaterialTheme.typography.titleMedium)
                                Spacer(Modifier.height(8.dp))
                                Text("Alto: $high")
                                Text("Normal: $normal")
                                Spacer(Modifier.height(12.dp))
                                BarChart(
                                    values = listOf(
                                        "Alto" to high.toFloat(),
                                        "Normal" to normal.toFloat()
                                    )
                                )
                            }
                        }
                    }
                }
            }

            // =========================
            // MÉTRICAS SOLO ENFERMERÍA
            // =========================
            if (role == "NURSING") {
                val vitals = cases.mapNotNull { c ->
                    val task = c.tasksSnapshot?.firstOrNull { t ->
                        t["code"]?.toString() == "UC3_4"
                    }
                    val data = task?.get("data") as? Map<String, Any>

                    val sbp = (data?.get("sbp") as? Number)?.toFloat()
                    val dbp = (data?.get("dbp") as? Number)?.toFloat()
                    val glu = (data?.get("glucose") as? Number)?.toFloat()

                    if (sbp != null && dbp != null && glu != null) {
                        Triple(sbp, dbp, glu)
                    } else null
                }

                if (vitals.isNotEmpty()) {
                    val avgSbp = vitals.map { it.first }.average().toFloat()
                    val avgDbp = vitals.map { it.second }.average().toFloat()
                    val avgGlu = vitals.map { it.third }.average().toFloat()

                    item {
                        Card {
                            Column(Modifier.padding(16.dp)) {
                                Text("📊 Constantes medias", style = MaterialTheme.typography.titleMedium)
                                Spacer(Modifier.height(8.dp))
                                Text("SBP: ${avgSbp.toInt()}")
                                Text("DBP: ${avgDbp.toInt()}")
                                Text("Glucosa: ${avgGlu.toInt()}")
                                Spacer(Modifier.height(12.dp))
                                BarChart(
                                    values = listOf(
                                        "SBP" to avgSbp,
                                        "DBP" to avgDbp,
                                        "GLU" to avgGlu
                                    )
                                )
                            }
                        }
                    }
                }
            }

            items(cases, key = { it.id }) { c ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    elevation = CardDefaults.cardElevation(4.dp),
                    onClick = {
                        navController.navigate(
                            Routes.ClosedCaseDetail + "/${c.id}/$role"
                        )
                    }
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp)
                    ) {
                        Text(
                            text = c.patientName.ifBlank { "Paciente" },
                            style = MaterialTheme.typography.titleMedium
                        )
                        Spacer(Modifier.height(4.dp))
                        Text("ID: ${c.patientId}")
                        Text("Destino: ${c.destination}")
                        Text("Cierre: ${fmt(c.closedAt)}")
                    }
                }
            }
        }
    }

    when (role) {
        "ADMISSION" -> AdmissionLayout(
            title = "Histórico",
            navController = navController,
            currentRoute = Routes.ClosedCasesAdmission,
            content = content
        )

        "NEURO" -> NeuroLayout(
            title = "Histórico",
            navController = navController,
            currentRoute = Routes.ClosedCasesNeuro,
            content = content
        )

        "NURSING" -> NursingLayout(
            title = "Histórico",
            navController = navController,
            currentRoute = Routes.ClosedCasesNursing,
            content = content
        )

        else -> AdmissionLayout(
            title = "Histórico",
            navController = navController,
            currentRoute = Routes.ClosedCasesAdmission,
            content = content
        )
    }
}