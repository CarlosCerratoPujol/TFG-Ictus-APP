package com.example.ictusapp.data

import com.google.firebase.Timestamp

data class ClosedCaseDetail(
    val id: String,
    val patientId: String,
    val patientName: String,
    val arrivalAt: com.google.firebase.Timestamp?,
    val destination: String,
    val closedAt: com.google.firebase.Timestamp?,
    val tasksSnapshot: List<Map<String, Any>>? = null,

    val uc1Eligible: Boolean?,
    val uc1CancelReason: String,
    val uc1AlternativePlan: String,

    val uc5TotalDoseMg: Double?,
    val uc5BolusMg: Double?,
    val uc5InfusionMg: Double?,

    val logs: List<LogEntry>,

    val hl7: String? = null
)