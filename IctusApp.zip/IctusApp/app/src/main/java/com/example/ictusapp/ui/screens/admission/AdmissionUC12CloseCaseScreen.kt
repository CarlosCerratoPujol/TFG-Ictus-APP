package com.example.ictusapp.ui.screens.admission

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.NavHostController
import com.example.ictusapp.data.AuthRepository
import com.example.ictusapp.data.CaseRepository
import com.example.ictusapp.ui.components.AdmissionLayout
import com.example.ictusapp.ui.navigation.Routes
import com.google.firebase.Timestamp
import java.util.Calendar

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AdmissionUC12CloseCaseScreen(navController: NavHostController, caseId: String) {

    val repo = CaseRepository()
    val auth = AuthRepository()

    val destinations = listOf("UCI", "Planta", "Domicilio", "Traslado")
    var destination by remember { mutableStateOf(destinations.first()) }
    var expanded by remember { mutableStateOf(false) }

    val cal = remember { Calendar.getInstance() }

    var year by remember { mutableStateOf(cal.get(Calendar.YEAR)) }
    var month by remember { mutableStateOf(cal.get(Calendar.MONTH)) }
    var day by remember { mutableStateOf(cal.get(Calendar.DAY_OF_MONTH)) }

    var hour by remember { mutableStateOf(cal.get(Calendar.HOUR_OF_DAY)) }
    var minute by remember { mutableStateOf(cal.get(Calendar.MINUTE)) }

    var showDatePicker by remember { mutableStateOf(false) }
    var showTimePicker by remember { mutableStateOf(false) }

    val datePickerState = rememberDatePickerState()
    val timePickerState = rememberTimePickerState(hour, minute, true)

    var loading by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }

    fun dischargeTimestamp(): Timestamp {
        val c = Calendar.getInstance()
        c.set(year, month, day, hour, minute, 0)
        c.set(Calendar.MILLISECOND, 0)
        return Timestamp(c.time)
    }

    fun validate(): String? {
        val ts = dischargeTimestamp()
        if (ts.seconds > Timestamp.now().seconds + 60) {
            return "La fecha no puede ser futura"
        }
        return null
    }

    // 📅 DatePicker
    if (showDatePicker) {
        DatePickerDialog(
            onDismissRequest = { showDatePicker = false },
            confirmButton = {
                TextButton(onClick = {
                    datePickerState.selectedDateMillis?.let {
                        val c = Calendar.getInstance()
                        c.timeInMillis = it
                        year = c.get(Calendar.YEAR)
                        month = c.get(Calendar.MONTH)
                        day = c.get(Calendar.DAY_OF_MONTH)
                    }
                    showDatePicker = false
                }) { Text("OK") }
            },
            dismissButton = {
                TextButton(onClick = { showDatePicker = false }) { Text("Cancelar") }
            }
        ) {
            DatePicker(state = datePickerState)
        }
    }

    // ⏱ TimePicker
    if (showTimePicker) {
        AlertDialog(
            onDismissRequest = { showTimePicker = false },
            confirmButton = {
                TextButton(onClick = {
                    hour = timePickerState.hour
                    minute = timePickerState.minute
                    showTimePicker = false
                }) { Text("OK") }
            },
            dismissButton = {
                TextButton(onClick = { showTimePicker = false }) { Text("Cancelar") }
            },
            title = { Text("Hora de alta") },
            text = { TimePicker(state = timePickerState) }
        )
    }

    // 🧱 LAYOUT CONSISTENTE
    AdmissionLayout(
        title = "UC12 — Alta y cierre",
        navController = navController,
        currentRoute = Routes.AdmissionHome
    ) { modifier ->

        Column(
            modifier = modifier
                .fillMaxSize()
                .padding(16.dp)
        ) {

            // 🟦 TARJETA DESTINO
            Card(
                elevation = CardDefaults.cardElevation(6.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(Modifier.padding(16.dp)) {

                    Text("🏥 Destino del paciente", style = MaterialTheme.typography.titleMedium)

                    Spacer(Modifier.height(12.dp))

                    ExposedDropdownMenuBox(
                        expanded = expanded,
                        onExpandedChange = { expanded = !expanded }
                    ) {
                        OutlinedTextField(
                            value = destination,
                            onValueChange = {},
                            readOnly = true,
                            label = { Text("Destino") },
                            trailingIcon = {
                                ExposedDropdownMenuDefaults.TrailingIcon(expanded)
                            },
                            modifier = Modifier
                                .menuAnchor(MenuAnchorType.PrimaryNotEditable, true)
                                .fillMaxWidth()
                        )

                        ExposedDropdownMenu(
                            expanded = expanded,
                            onDismissRequest = { expanded = false }
                        ) {
                            destinations.forEach {
                                DropdownMenuItem(
                                    text = { Text(it) },
                                    onClick = {
                                        destination = it
                                        expanded = false
                                    }
                                )
                            }
                        }
                    }
                }
            }

            Spacer(Modifier.height(16.dp))

            // 🟦 TARJETA FECHA/HORA
            Card(
                elevation = CardDefaults.cardElevation(6.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(Modifier.padding(16.dp)) {

                    Text("⏱ Fecha de alta", style = MaterialTheme.typography.titleMedium)

                    Spacer(Modifier.height(12.dp))

                    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        OutlinedButton(onClick = { showDatePicker = true }) {
                            Text("Fecha")
                        }
                        OutlinedButton(onClick = { showTimePicker = true }) {
                            Text("Hora")
                        }
                    }

                    Spacer(Modifier.height(8.dp))

                    Text(
                        "Seleccionado: %02d/%02d/%04d %02d:%02d"
                            .format(day, month + 1, year, hour, minute)
                    )
                }
            }

            Spacer(Modifier.height(16.dp))

            error?.let {
                Text(it, color = MaterialTheme.colorScheme.error)
            }

            Spacer(Modifier.height(16.dp))

            // 🚀 BOTÓN CIERRE
            Button(
                onClick = {
                    val err = validate()
                    if (err != null) {
                        error = err
                        return@Button
                    }

                    loading = true
                    error = null

                    val ts = dischargeTimestamp()

                    repo.completeTask(
                        caseId,
                        "UC12",
                        mapOf("destination" to destination, "dischargeAt" to ts),
                        onOk = {
                            repo.closeCase(
                                caseId,
                                destination,
                                auth.currentUid() ?: "unknown",
                                ts,
                                onOk = {
                                    loading = false
                                    navController.navigate(Routes.AdmissionHome) {
                                        popUpTo(Routes.AdmissionHome) { inclusive = true }
                                    }
                                },
                                onErr = {
                                    loading = false
                                    error = it
                                }
                            )
                        },
                        onErr = {
                            loading = false
                            error = it
                        }
                    )
                },
                enabled = !loading,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(if (loading) "Cerrando..." else "Cerrar caso clínico")
            }
        }
    }
}

