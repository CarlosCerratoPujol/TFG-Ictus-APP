package com.example.ictusapp.data

object HL7Builder {

    fun buildClosedCase(
        patientId: String,
        patientName: String,
        destination: String,
        closedAt: String
    ): String {

        val msh = "MSH|^~\\&|ICTUSAPP|HOSPITAL|RECEIVER|HOSPITAL|${System.currentTimeMillis()}||ORU^R01|1|P|2.3"

        val pid = "PID|1||$patientId||$patientName"

        val pv1 = "PV1|1|E|||||||||||||||||||||||||||||||||||||||||"

        val obx1 = "OBX|1||DESTINO||$destination"
        val obx2 = "OBX|2||CERRADO||$closedAt"

        return listOf(msh, pid, pv1, obx1, obx2).joinToString("\n")
    }
}