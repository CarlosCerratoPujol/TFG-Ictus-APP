package com.example.ictusapp.ui.components

import androidx.compose.foundation.layout.padding
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.navigation.NavHostController
import com.example.ictusapp.data.AuthRepository
import com.example.ictusapp.ui.navigation.Routes

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NursingLayout(
    title: String,
    navController: NavHostController,
    currentRoute: String,
    content: @Composable (Modifier) -> Unit
) {
    val authRepo = AuthRepository()

    Scaffold(
        topBar = {
            TopAppBar(title = { Text(title) })
        },
        bottomBar = {
            NavigationBar {

                NavigationBarItem(
                    selected = currentRoute == Routes.NursingHome,
                    onClick = { navController.navigate(Routes.NursingHome) },
                    icon = { Text("🩺") },
                    label = { Text("Pacientes") }
                )

                NavigationBarItem(
                    selected = currentRoute == Routes.ClosedCasesNursing,
                    onClick = { navController.navigate(Routes.ClosedCasesNursing) },
                    icon = { Text("📁") },
                    label = { Text("Histórico") }
                )

                NavigationBarItem(
                    selected = false,
                    onClick = {
                        authRepo.logout()
                        navController.navigate(Routes.Login) {
                            popUpTo(0)
                        }
                    },
                    icon = { Text("🚪") },
                    label = { Text("Salir") }
                )
            }
        }
    ) { innerPadding ->
        content(Modifier.padding(innerPadding))
    }
}