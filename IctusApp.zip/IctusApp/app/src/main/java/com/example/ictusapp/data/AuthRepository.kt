package com.example.ictusapp.data

import com.google.firebase.auth.FirebaseAuth

class AuthRepository(
    private val auth: FirebaseAuth = FirebaseAuth.getInstance()
) {
    fun currentUid(): String? = auth.currentUser?.uid
    fun currentEmail(): String? = auth.currentUser?.email

    fun login(email: String, pass: String, onOk: () -> Unit, onErr: (String) -> Unit) {
        auth.signInWithEmailAndPassword(email, pass)
            .addOnSuccessListener { onOk() }
            .addOnFailureListener { onErr(it.message ?: "Error login") }
    }

    fun register(email: String, pass: String, onOk: (String) -> Unit, onErr: (String) -> Unit) {
        auth.createUserWithEmailAndPassword(email, pass)
            .addOnSuccessListener { res -> onOk(res.user?.uid ?: "") }
            .addOnFailureListener { onErr(it.message ?: "Error registro") }
    }

    fun deleteCurrentUser(onOk: () -> Unit, onErr: (String) -> Unit) {
        val u = auth.currentUser ?: run { onErr("No hay usuario"); return }
        u.delete()
            .addOnSuccessListener { onOk() }
            .addOnFailureListener { onErr(it.message ?: "No se pudo borrar usuario") }
    }

    fun logout() {
        auth.signOut()
    }
}


