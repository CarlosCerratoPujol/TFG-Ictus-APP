package com.example.ictusapp.ui.screens.admin

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.NavHostController
import com.example.ictusapp.ui.components.AdminLayout
import com.example.ictusapp.ui.navigation.Routes

@Composable
fun AdminHomeScreen(navController: NavHostController) {

    AdminLayout(
        title = "Panel de Administración",
        navController = navController,
        currentRoute = Routes.AdminHome
    ) { modifier ->

        Column(
            modifier = modifier.padding(16.dp)
        ) {

            // 🟦 Tarjeta bienvenida
            Card(
                modifier = Modifier.padding(bottom = 16.dp),
                elevation = CardDefaults.cardElevation(4.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("👨‍💼 Bienvenido Admin")
                    Text("Gestiona usuarios y supervisa el sistema")
                }
            }

            // 🟦 Tarjeta info
            Card(
                modifier = Modifier.padding(bottom = 16.dp),
                elevation = CardDefaults.cardElevation(4.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("📊 Sistema IctusApp")
                    Text("Desde aquí puedes crear usuarios y ver el estado del sistema")
                }
            }

        }
    }
}