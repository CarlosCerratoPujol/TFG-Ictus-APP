package com.example.ictusapp.ui.components

import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.navigation.NavHostController
import com.example.ictusapp.data.AuthRepository
import com.example.ictusapp.ui.navigation.Routes
import androidx.compose.foundation.layout.padding

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainLayout(
    title: String,
    navController: NavHostController,
    currentRoute: String,
    content: @Composable (Modifier) -> Unit
) {
    val authRepo = AuthRepository()

    Scaffold(
        topBar = {
            TopAppBar(title = { Text(title) })
        },
        bottomBar = {
            NavigationBar {
                NavigationBarItem(
                    selected = currentRoute == Routes.AdminHome,
                    onClick = { navController.navigate(Routes.AdminHome) },
                    icon = { Text("🏠") },
                    label = { Text("Inicio") }
                )
                NavigationBarItem(
                    selected = currentRoute == Routes.AdminUsers,
                    onClick = { navController.navigate(Routes.AdminUsers) },
                    icon = { Text("👥") },
                    label = { Text("Usuarios") }
                )
                NavigationBarItem(
                    selected = false,
                    onClick = {
                        authRepo.logout()
                        navController.navigate(Routes.Login) {
                            popUpTo(0)
                        }
                    },
                    icon = { Text("🚪") },
                    label = { Text("Salir") }
                )
            }
        }
    ) { innerPadding ->
        content(Modifier.padding(innerPadding))
    }
}