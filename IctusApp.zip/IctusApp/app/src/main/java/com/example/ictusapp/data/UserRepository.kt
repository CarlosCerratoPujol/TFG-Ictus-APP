
package com.example.ictusapp.data

import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ListenerRegistration

enum class Role { ADMIN, NEURO, NURSING, ADMISSION }

data class AppUser(
    val id: String = "",
    val email: String = "",
    val role: String = "",
    val active: Boolean = true
)

class UserRepository(
    private val db: FirebaseFirestore = FirebaseFirestore.getInstance()
) {
    fun getRole(uid: String, onOk: (Role) -> Unit, onErr: (String) -> Unit) {
        db.collection("users").document(uid).get()
            .addOnSuccessListener { doc ->
                val roleStrRaw = doc.getString("role") ?: ""
                val roleStr = roleStrRaw.trim().uppercase()

                val role = runCatching { Role.valueOf(roleStr) }.getOrNull()
                if (role == null) onErr("Rol no válido: '$roleStrRaw'")
                else onOk(role)
            }
            .addOnFailureListener { onErr(it.message ?: "Error leyendo rol") }
    }

    fun setAdminUser(uid: String, email: String, onOk: () -> Unit, onErr: (String) -> Unit) {
        val data = mapOf(
            "email" to email,
            "role" to Role.ADMIN.name,
            "active" to true
        )
        db.collection("users").document(uid).set(data)
            .addOnSuccessListener { onOk() }
            .addOnFailureListener { onErr(it.message ?: "Error guardando usuario") }
    }

    // ---- Admin crea "usuarios staff" (de momento en Firestore) ----
    fun createStaffUser(
        email: String,
        role: String,
        onOk: () -> Unit,
        onErr: (String) -> Unit
    ) {
        val emailLower = email.trim().lowercase()
        val ref = db.collection("staff").document(emailLower)

        val data = hashMapOf(
            "email" to email.trim(),
            "emailLower" to emailLower,
            "role" to role.trim().uppercase(),
            "active" to true,
            "createdAt" to com.google.firebase.Timestamp.now()
        )

        ref.set(data)
            .addOnSuccessListener { onOk() }
            .addOnFailureListener { onErr(it.message ?: "Error guardando staff") }
    }
    fun findStaffRoleByEmail(
        email: String,
        onOk: (String?) -> Unit,
        onErr: (String) -> Unit
    ) {
        val emailLower = email.trim().lowercase()
        db.collection("staff").document(emailLower).get()
            .addOnSuccessListener { doc ->
                if (!doc.exists()) onOk(null)
                else onOk(doc.getString("role"))
            }
            .addOnFailureListener { onErr(it.message ?: "Error buscando staff") }
    }

    fun setUserRole(
        uid: String,
        email: String,
        role: String,
        onOk: () -> Unit,
        onErr: (String) -> Unit
    ) {
        val data = hashMapOf(
            "uid" to uid,
            "email" to email.trim(),
            "role" to role.trim().uppercase(),

            "active" to true,
            "updatedAt" to com.google.firebase.Timestamp.now()
        )

        db.collection("users").document(uid).set(data)
            .addOnSuccessListener { onOk() }
            .addOnFailureListener { onErr(it.message ?: "Error guardando user") }
    }

    fun getUserRole(
        uid: String,
        onOk: (String?) -> Unit,
        onErr: (String) -> Unit
    ) {
        db.collection("users").document(uid).get()
            .addOnSuccessListener { doc -> onOk(doc.getString("role")) }
            .addOnFailureListener { onErr(it.message ?: "Error leyendo rol") }
    }


    fun listenStaffUsers(
        onUpdate: (List<AppUser>) -> Unit,
        onErr: (String) -> Unit
    ): ListenerRegistration {
        return db.collection("staff")
            .addSnapshotListener { snap, e ->
                if (e != null) {
                    onErr(e.message ?: "Error escuchando usuarios")
                    return@addSnapshotListener
                }

                val users = snap?.documents?.map { doc ->
                    AppUser(
                        id = doc.id,
                        email = doc.getString("email") ?: "",
                        role = doc.getString("role") ?: "",
                        active = doc.getBoolean("active") ?: true
                    )
                }.orEmpty()

                onUpdate(users)
            }
    }
}



