package com.example.ictusapp.data

import com.google.firebase.Timestamp
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ListenerRegistration

data class ClosedCaseItem(
    val id: String = "",
    val patientId: String = "",
    val patientName: String = "",
    val destination: String = "",
    val closedAt: com.google.firebase.Timestamp? = null,
    val tasksSnapshot: List<Map<String, Any>>? = null
)

data class LogEntry(
    val message: String = "",
    val at: com.google.firebase.Timestamp? = null
)


data class CaseItem(
    val id: String = "",
    val patientId: String = "",
    val patientName: String = "",
    val status: String = "ACTIVE",
    val arrivalAt: Timestamp? = null,
    val createdAt: Timestamp? = null
)

data class TaskItem(
    val code: String = "",
    val title: String = "",
    val role: String = "",
    val done: Boolean = false,
    val doneAt: Timestamp? = null
)

class CaseRepository(
    private val db: FirebaseFirestore = FirebaseFirestore.getInstance()
) {
    companion object {
        const val ROLE_ADMISSION = "ADMISSION"
        const val ROLE_NEURO = "NEURO"
        const val ROLE_NURSING = "NURSING"
        const val ROLE_AUTO = "AUTO"

        const val STATUS_ACTIVE = "ACTIVE"
        const val STATUS_CLOSED = "CLOSED"
    }

    // ---- Plantilla de tareas por caso (con tus uniones) ----
    private fun initialTasks(): List<Map<String, Any>> = listOf(
        mapOf("code" to "UC1", "title" to "Elegibilidad trombólisis (Neuro)", "role" to ROLE_NEURO, "done" to false),

        mapOf("code" to "UC2", "title" to "Registrar peso (Enfermería)", "role" to ROLE_NURSING, "done" to false),

        // UC3 + UC4 juntas
        mapOf("code" to "UC3_4", "title" to "TA/Glucemia + manejo", "role" to ROLE_NURSING, "done" to false),

        mapOf("code" to "UC5", "title" to "Calcular dosis alteplasa", "role" to ROLE_NEURO, "done" to false),

        mapOf("code" to "UC6", "title" to "Doble verificación (id + dosis)", "role" to ROLE_NURSING, "done" to false),

        // UC7 + UC8 juntas
        mapOf("code" to "UC7_8", "title" to "Administrar alteplasa (bolo + perfusión)", "role" to ROLE_NURSING, "done" to false),

        mapOf("code" to "UC9", "title" to "Controles durante perfusión (NIHSS/TA)", "role" to ROLE_NURSING, "done" to false),

        mapOf("code" to "UC10", "title" to "Interrumpir perfusión (si procede)", "role" to ROLE_NURSING, "done" to false),

        mapOf("code" to "UC11", "title" to "Notificación/registro automático", "role" to ROLE_AUTO, "done" to false),

        mapOf("code" to "UC12", "title" to "Destino/Alta y cierre (Admisión)", "role" to ROLE_ADMISSION, "done" to false)
    )

    /**
     * Crea un caso en /cases y crea todas las tareas en /cases/{id}/tasks con docId = code (UC1, UC2...)
     */
    fun createCase(
        patientId: String,
        patientName: String,
        arrivalAt: Timestamp,
        createdByUid: String,
        onOk: (caseId: String) -> Unit,
        onErr: (String) -> Unit
    ) {
        val caseRef = db.collection("cases").document()

        val caseData = hashMapOf(
            "patientId" to patientId,
            "patientName" to patientName,
            "arrivalAt" to arrivalAt,
            "createdByUid" to createdByUid,
            "status" to STATUS_ACTIVE,
            "createdAt" to Timestamp.now(),
            "assignedRoles" to listOf(ROLE_ADMISSION, ROLE_NEURO, ROLE_NURSING)
        )

        val batch = db.batch()
        batch.set(caseRef, caseData)

        initialTasks().forEach { t ->
            val code = t["code"] as String
            val taskRef = caseRef.collection("tasks").document(code)
            batch.set(taskRef, t)
        }

        batch.commit()
            .addOnSuccessListener { onOk(caseRef.id) }
            .addOnFailureListener { onErr(it.message ?: "Error creando caso") }
    }
    fun listenTurnForRole(
        caseId: String,
        role: String,
        onUpdate: (hasTurn: Boolean, nextCode: String?) -> Unit,
        onErr: (String) -> Unit
    ): ListenerRegistration {

        val order = listOf("UC1","UC2","UC3_4","UC5","UC6","UC7_8","UC9","UC10","UC11","UC12")

        return db.collection("cases").document(caseId)
            .collection("tasks")
            .addSnapshotListener { snap, e ->
                if (e != null) {
                    onErr(e.message ?: "Error escuchando turno")
                    return@addSnapshotListener
                }

                val tasks = snap?.documents?.map { doc ->
                    TaskItem(
                        code = doc.getString("code") ?: doc.id,
                        title = doc.getString("title") ?: "",
                        role = doc.getString("role") ?: "",
                        done = doc.getBoolean("done") ?: false,
                        doneAt = doc.getTimestamp("doneAt")
                    )
                }.orEmpty()

                val byCode = tasks.associateBy { it.code }

                val nextCode = order.firstOrNull { code ->
                    val t = byCode[code]
                    t != null && !t.done
                }

                if (nextCode == null) {
                    onUpdate(false, null) //
                    return@addSnapshotListener
                }

                val nextTask = byCode[nextCode]
                val hasTurn = (nextTask?.role == role)

                onUpdate(hasTurn, nextCode)
            }
    }


    fun completeTask(
        caseId: String,
        taskCode: String,
        data: Map<String, Any> = emptyMap(),
        onOk: () -> Unit,
        onErr: (String) -> Unit
    ) {
        val caseRef = db.collection("cases").document(caseId)
        val taskRef = caseRef.collection("tasks").document(taskCode)

        val update = hashMapOf<String, Any>(
            "done" to true,
            "doneAt" to Timestamp.now()
        )
        if (data.isNotEmpty()) update["data"] = data

        taskRef.update(update)
            .addOnSuccessListener {
                // ✅ UC9 -> auto UC11 (si no hay evento adverso)
                if (taskCode == "UC9") {
                    val autoRef = caseRef.collection("tasks").document("UC11")
                    autoRef.update(
                        mapOf(
                            "done" to true,
                            "doneAt" to Timestamp.now(),
                            "data" to mapOf("autoCompletedFrom" to "UC9")
                        )
                    ).addOnSuccessListener {
                        caseRef.collection("logs").document().set(
                            mapOf("message" to "UC11: Registro automático tras UC9", "at" to Timestamp.now())
                        )
                        onOk()
                    }.addOnFailureListener { e ->
                        onErr(e.message ?: "UC9 ok pero UC11 auto falló")
                    }
                    return@addOnSuccessListener
                }

                // (tu lógica anterior de UC10 -> UC11 si quieres mantenerla)
                if (taskCode == "UC10") {
                    val autoRef = caseRef.collection("tasks").document("UC11")
                    autoRef.update(
                        mapOf(
                            "done" to true,
                            "doneAt" to Timestamp.now(),
                            "data" to mapOf("autoCompletedFrom" to "UC10")
                        )
                    ).addOnSuccessListener {
                        caseRef.collection("logs").document().set(
                            mapOf("message" to "UC11: Registro automático tras UC10", "at" to Timestamp.now())
                        )
                        onOk()
                    }.addOnFailureListener { e ->
                        onErr(e.message ?: "UC10 ok pero UC11 auto falló")
                    }
                    return@addOnSuccessListener
                }

                onOk()
            }
            .addOnFailureListener { onErr(it.message ?: "Error completando tarea") }
    }
    fun closeCaseAdverse(
        caseId: String,
        closedByUid: String,
        onOk: () -> Unit,
        onErr: (String) -> Unit
    ) {
        closeCase(
            caseId = caseId,
            destination = "EVENTO ADVERSO",
            closedByUid = closedByUid,
            dischargeAt = Timestamp.now(),
            onOk = onOk,
            onErr = onErr
        )
    }

    fun markAdverseEvent(
        caseId: String,
        reason: String,
        byUid: String,
        onOk: () -> Unit,
        onErr: (String) -> Unit
    ) {
        db.collection("cases").document(caseId)
            .update(
                mapOf(
                    "adverseEvent" to true,
                    "adverseReason" to reason.trim(),
                    "adverseAt" to Timestamp.now(),
                    "adverseByUid" to byUid
                )
            )
            .addOnSuccessListener { onOk() }
            .addOnFailureListener { onErr(it.message ?: "Error guardando evento adverso") }
    }




    fun listenClosedCasesForRole(
        role: String,
        onUpdate: (List<ClosedCaseItem>) -> Unit,
        onErr: (String) -> Unit
    ): ListenerRegistration {

        val q = if (role == "ADMIN") {
            db.collection("cases_closed")
        } else {
            db.collection("cases_closed").whereArrayContains("assignedRoles", role)
        }

        return q.addSnapshotListener { snap, e ->
            if (e != null) {
                onErr(e.message ?: "Error escuchando histórico")
                return@addSnapshotListener
            }

            val cases = snap?.documents?.map { doc ->

                val rawTasks = doc.get("tasksSnapshot") as? List<Map<String, Any>>

                ClosedCaseItem(
                    id = doc.id,
                    patientId = doc.getString("patientId") ?: "",
                    patientName = doc.getString("patientName") ?: "",
                    destination = doc.getString("destination") ?: "",
                    closedAt = doc.getTimestamp("closedAt"),
                    tasksSnapshot = rawTasks // 🔥 IMPORTANTE
                )
            }.orEmpty()

            onUpdate(cases)
        }
    }

    fun getClosedCaseDetail(
        caseId: String,
        onOk: (ClosedCaseDetail) -> Unit,
        onErr: (String) -> Unit
    ) {
        db.collection("cases_closed").document(caseId).get()
            .addOnSuccessListener { doc ->
                if (!doc.exists()) {
                    onErr("No existe el caso cerrado")
                    return@addOnSuccessListener
                }

                val data = doc.data ?: emptyMap<String, Any>()

                fun anyToStringAnyMap(x: Any?): Map<String, Any>? {
                    val raw = x as? Map<*, *> ?: return null
                    val out = mutableMapOf<String, Any>()
                    for ((k, v) in raw) {
                        val key = k?.toString() ?: continue
                        if (v != null) out[key] = v
                    }
                    return out
                }

                fun anyToListOfStringAnyMap(x: Any?): List<Map<String, Any>> {
                    val rawList = x as? List<*> ?: return emptyList()
                    return rawList.mapNotNull { anyToStringAnyMap(it) }
                }

                val tasks: List<Map<String, Any>> = anyToListOfStringAnyMap(data["tasksSnapshot"])
                val logsMaps: List<Map<String, Any>> = anyToListOfStringAnyMap(data["logs"])

                val logs = logsMaps.map {
                    LogEntry(
                        message = it["message"] as? String ?: "",
                        at = it["at"] as? com.google.firebase.Timestamp
                    )
                }

                fun findTask(code: String): Map<String, Any>? =
                    tasks.firstOrNull { (it["code"]?.toString() ?: "") == code }

                val uc1 = anyToStringAnyMap(findTask("UC1")?.get("data"))
                val uc5 = anyToStringAnyMap(findTask("UC5")?.get("data"))

                val uc5Total = (uc5?.get("totalDoseMg") as? Number)?.toDouble()
                val uc5Bolus = (uc5?.get("bolusMg") as? Number)?.toDouble()
                    ?: (uc5?.get("bolusDoseMg") as? Number)?.toDouble()
                val uc5Infusion = (uc5?.get("infusionMg") as? Number)?.toDouble()
                    ?: (uc5?.get("infusionDoseMg") as? Number)?.toDouble()

                // 🔥 AÑADIR ESTO
                val hl7 = doc.getString("hl7")
                val rawTasks = doc.get("tasksSnapshot") as? List<Map<String, Any>>

                val detail = ClosedCaseDetail(
                    id = doc.id,
                    patientId = doc.getString("patientId") ?: "",
                    patientName = doc.getString("patientName") ?: "",
                    arrivalAt = doc.getTimestamp("arrivalAt"),
                    destination = doc.getString("destination") ?: "",
                    closedAt = doc.getTimestamp("closedAt"),
                    tasksSnapshot = rawTasks,
                    uc1Eligible = uc1?.get("eligible") as? Boolean,
                    uc1CancelReason = uc1?.get("cancelReason") as? String ?: "",
                    uc1AlternativePlan = uc1?.get("alternativePlan") as? String ?: "",
                    uc5TotalDoseMg = uc5Total,
                    uc5BolusMg = uc5Bolus,
                    uc5InfusionMg = uc5Infusion,
                    logs = logs,
                    hl7 = hl7
                )


                onOk(detail)
            }
            .addOnFailureListener { onErr(it.message ?: "Error leyendo detalle") }
    }




    fun listenActiveCasesForRole(
        role: String,
        onUpdate: (List<CaseItem>) -> Unit,
        onErr: (String) -> Unit
    ): ListenerRegistration {
        return db.collection("cases")
            .whereEqualTo("status", STATUS_ACTIVE)
            .whereArrayContains("assignedRoles", role)
            .addSnapshotListener { snap, e ->
                if (e != null) {
                    onErr(e.message ?: "Error escuchando casos")
                    return@addSnapshotListener
                }
                val cases = snap?.documents?.map { doc ->
                    CaseItem(
                        id = doc.id,
                        patientId = doc.getString("patientId") ?: "",
                        patientName = doc.getString("patientName") ?: "",
                        status = doc.getString("status") ?: STATUS_ACTIVE,
                        arrivalAt = doc.getTimestamp("arrivalAt"),
                        createdAt = doc.getTimestamp("createdAt")
                    )
                }.orEmpty()
                onUpdate(cases)
            }
    }

    fun closeCaseNotEligible(
        caseId: String,
        cancelReason: String,
        alternativePlan: String,
        closedByEmail: String,
        onOk: () -> Unit,
        onErr: (String) -> Unit
    ) {
        val data = hashMapOf<String, Any>(
            "status" to STATUS_CLOSED,
            "closedReasonType" to "NOT_ELIGIBLE",
            "thrombolysisEligible" to false,
            "thrombolysisCancelled" to true,
            "cancelReason" to cancelReason.trim(),
            "alternativePlan" to alternativePlan.trim(),
            "closedAt" to Timestamp.now(),
            "closedBy" to closedByEmail
        )

        db.collection("cases").document(caseId)
            .update(data)
            .addOnSuccessListener { onOk() }
            .addOnFailureListener { onErr(it.message ?: "Error cerrando caso") }
    }

    fun listenTasksForCase(
        caseId: String,
        onUpdate: (List<TaskItem>) -> Unit,
        onErr: (String) -> Unit
    ): ListenerRegistration {
        return db.collection("cases").document(caseId)
            .collection("tasks")
            .addSnapshotListener { snap, e ->
                if (e != null) {
                    onErr(e.message ?: "Error escuchando tareas")
                    return@addSnapshotListener
                }
                val tasks = snap?.documents?.map { doc ->
                    TaskItem(
                        code = doc.getString("code") ?: doc.id,
                        title = doc.getString("title") ?: "",
                        role = doc.getString("role") ?: "",
                        done = doc.getBoolean("done") ?: false,
                        doneAt = doc.getTimestamp("doneAt")
                    )
                }.orEmpty()
                onUpdate(tasks)
            }
    }




    // UC9: añadir un control (registro repetible)
    fun addControl(
        caseId: String,
        controlData: Map<String, Any>,
        onOk: () -> Unit,
        onErr: (String) -> Unit
    ) {
        val ref = db.collection("cases").document(caseId)
            .collection("controls").document()

        val data = HashMap(controlData)
        data["createdAt"] = Timestamp.now()

        ref.set(data)
            .addOnSuccessListener { onOk() }
            .addOnFailureListener { onErr(it.message ?: "Error guardando control") }
    }

    // UC12: cerrar caso (mueve a histórico y marca status=CLOSED)
    fun closeCase(
        caseId: String,
        destination: String,
        closedByUid: String,
        dischargeAt: Timestamp,
        onOk: () -> Unit,
        onErr: (String) -> Unit
    ) {
        val caseRef = db.collection("cases").document(caseId)
        val closedRef = db.collection("cases_closed").document(caseId)

        caseRef.get()
            .addOnSuccessListener { doc ->
                if (!doc.exists()) {
                    onErr("El caso no existe")
                    return@addOnSuccessListener
                }

                val current = doc.data ?: emptyMap<String, Any>()
                val copy = HashMap(current)
                copy["status"] = STATUS_CLOSED
                copy["destination"] = destination
                copy["closedAt"] = dischargeAt
                copy["closedByUid"] = closedByUid
                copy["migratedAt"] = Timestamp.now()

                // 🔥 GENERAR HL7
                val patientId = copy["patientId"] as? String ?: ""
                val patientName = copy["patientName"] as? String ?: ""
                val closedAtStr = dischargeAt.toDate().toString()

                val hl7 = HL7Builder.buildClosedCase(
                    patientId = patientId,
                    patientName = patientName,
                    destination = destination,
                    closedAt = closedAtStr
                )

                copy["hl7"] = hl7

                // 1) Leemos tareas del caso para guardarlas como snapshot
                caseRef.collection("tasks").get()
                    .addOnSuccessListener { tasksSnap ->
                        val tasksList = tasksSnap.documents.map { tdoc ->
                            val m = HashMap<String, Any>()
                            m["code"] = tdoc.getString("code") ?: tdoc.id
                            m["title"] = tdoc.getString("title") ?: ""
                            m["role"] = tdoc.getString("role") ?: ""
                            m["done"] = tdoc.getBoolean("done") ?: false
                            tdoc.getTimestamp("doneAt")?.let { m["doneAt"] = it }
                            val dataField = tdoc.get("data")
                            if (dataField != null) m["data"] = dataField
                            m
                        }
                        copy["tasksSnapshot"] = tasksList

                        // 2) Logs (si existen)
                        caseRef.collection("logs").get()
                            .addOnSuccessListener { logsSnap ->
                                val logs = logsSnap.documents.map { ldoc ->
                                    mapOf(
                                        "message" to (ldoc.getString("message") ?: ""),
                                        "at" to (ldoc.getTimestamp("at") ?: Timestamp.now())
                                    )
                                }
                                copy["logs"] = logs

                                val batch = db.batch()
                                batch.set(closedRef, copy)
                                batch.update(caseRef, mapOf(
                                    "status" to STATUS_CLOSED,
                                    "destination" to destination,
                                    "closedAt" to dischargeAt,
                                    "closedByUid" to closedByUid
                                ))

                                batch.commit()
                                    .addOnSuccessListener { onOk() }
                                    .addOnFailureListener { onErr(it.message ?: "Error cerrando caso") }
                            }
                            .addOnFailureListener { onErr(it.message ?: "Error leyendo logs") }
                    }
                    .addOnFailureListener { onErr(it.message ?: "Error leyendo tareas") }
            }
            .addOnFailureListener { onErr(it.message ?: "Error leyendo caso") }
    }
}

