package com.example.ictusapp.ui.screens.admission

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.TimePicker
import androidx.compose.material3.rememberDatePickerState
import androidx.compose.material3.rememberTimePickerState
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.NavHostController
import com.example.ictusapp.data.AuthRepository
import com.example.ictusapp.data.CaseRepository
import com.example.ictusapp.ui.components.AdmissionLayout
import com.example.ictusapp.ui.navigation.Routes
import com.google.firebase.Timestamp
import java.time.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AdmissionCreateCaseScreen(navController: NavHostController) {

    val repo = CaseRepository()
    val auth = AuthRepository()

    var patientId by remember { mutableStateOf("") }
    var patientName by remember { mutableStateOf("") }

    var selectedDate by remember { mutableStateOf(LocalDate.now()) }
    var selectedTime by remember { mutableStateOf(LocalTime.now().withSecond(0).withNano(0)) }

    var showDateDialog by remember { mutableStateOf(false) }
    var showTimeDialog by remember { mutableStateOf(false) }

    var loading by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }

    // 📅 DatePicker
    if (showDateDialog) {
        val initialMillis = selectedDate
            .atStartOfDay(ZoneId.systemDefault())
            .toInstant()
            .toEpochMilli()

        val dateState = rememberDatePickerState(initialSelectedDateMillis = initialMillis)

        DatePickerDialog(
            onDismissRequest = { showDateDialog = false },
            confirmButton = {
                TextButton(onClick = {
                    dateState.selectedDateMillis?.let {
                        selectedDate = Instant.ofEpochMilli(it)
                            .atZone(ZoneId.systemDefault())
                            .toLocalDate()
                    }
                    showDateDialog = false
                }) { Text("OK") }
            },
            dismissButton = {
                TextButton(onClick = { showDateDialog = false }) { Text("Cancelar") }
            }
        ) {
            DatePicker(state = dateState)
        }
    }

    // ⏱ TimePicker
    if (showTimeDialog) {
        val timeState = rememberTimePickerState(
            initialHour = selectedTime.hour,
            initialMinute = selectedTime.minute,
            is24Hour = true
        )

        AlertDialog(
            onDismissRequest = { showTimeDialog = false },
            confirmButton = {
                TextButton(onClick = {
                    selectedTime = LocalTime.of(timeState.hour, timeState.minute)
                    showTimeDialog = false
                }) { Text("OK") }
            },
            dismissButton = {
                TextButton(onClick = { showTimeDialog = false }) { Text("Cancelar") }
            },
            title = { Text("Hora de llegada") },
            text = { TimePicker(state = timeState) }
        )
    }

    // 🧱 LAYOUT CONSISTENTE
    AdmissionLayout(
        title = "Nuevo caso clínico",
        navController = navController,
        currentRoute = Routes.AdmissionCreateCase
    ) { modifier ->

        Column(
            modifier = modifier
                .fillMaxSize()
                .padding(16.dp)
        ) {

            // 🟦 TARJETA DATOS PACIENTE
            Card(
                elevation = CardDefaults.cardElevation(6.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(Modifier.padding(16.dp)) {

                    Text("🧑 Paciente", style = MaterialTheme.typography.titleMedium)

                    Spacer(Modifier.height(12.dp))

                    OutlinedTextField(
                        value = patientId,
                        onValueChange = { patientId = it },
                        label = { Text("Identificador (NHC/DNI)") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )

                    Spacer(Modifier.height(8.dp))

                    OutlinedTextField(
                        value = patientName,
                        onValueChange = { patientName = it },
                        label = { Text("Nombre (opcional)") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }

            Spacer(Modifier.height(16.dp))

            // 🟦 TARJETA FECHA/HORA
            Card(
                elevation = CardDefaults.cardElevation(6.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(Modifier.padding(16.dp)) {

                    Text("⏱ Llegada", style = MaterialTheme.typography.titleMedium)

                    Spacer(Modifier.height(12.dp))

                    Row(
                        Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {

                        OutlinedButton(
                            onClick = { showDateDialog = true },
                            modifier = Modifier.weight(1f)
                        ) {
                            Text(selectedDate.toString())
                        }

                        OutlinedButton(
                            onClick = { showTimeDialog = true },
                            modifier = Modifier.weight(1f)
                        ) {
                            Text(String.format("%02d:%02d", selectedTime.hour, selectedTime.minute))
                        }
                    }
                }
            }

            Spacer(Modifier.height(16.dp))

            // ❌ ERROR
            error?.let {
                Text(it, color = MaterialTheme.colorScheme.error)
            }

            Spacer(Modifier.height(16.dp))

            // 🚀 BOTÓN CREAR
            Button(
                onClick = {
                    val uid = auth.currentUid()
                    if (uid == null) {
                        error = "Sesión inválida"
                        return@Button
                    }

                    if (patientId.isBlank()) {
                        error = "El identificador es obligatorio"
                        return@Button
                    }

                    loading = true
                    error = null

                    val dt = LocalDateTime.of(selectedDate, selectedTime)
                    val instant = dt.atZone(ZoneId.systemDefault()).toInstant()
                    val ts = Timestamp(instant.epochSecond, 0)

                    repo.createCase(
                        patientId = patientId.trim(),
                        patientName = patientName.trim(),
                        arrivalAt = ts,
                        createdByUid = uid,
                        onOk = {
                            loading = false
                            navController.popBackStack()
                        },
                        onErr = {
                            loading = false
                            error = it
                        }
                    )
                },
                enabled = !loading,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(if (loading) "Creando..." else "Crear caso clínico")
            }
        }
    }
}