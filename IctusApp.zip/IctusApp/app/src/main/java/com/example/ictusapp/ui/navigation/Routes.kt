package com.example.ictusapp.ui.navigation

object Routes {
    const val Splash = "splash"
    const val Login = "login"
    const val RegisterAdmin = "register_admin"
    const val AdminUsers = "admin_users"
    const val AdminCreateUser = "admin_create_user"

    const val AdminHome = "admin_home"
    const val NeuroHome = "neuro_home"
    const val NursingHome = "nursing_home"
    const val AdmissionHome = "admission_home"
    const val AdmissionCreateCase = "admission_create_case"
    const val RegisterStaff = "register_staff"
    // Enfermería
    const val NursingCaseTasks = "nursing_case_tasks"
    const val NursingUC2 = "nursing_uc2"
    const val NursingUC3_4 = "nursing_uc3_4"
    const val NursingUC6 = "nursing_uc6"
    const val NursingUC7_8 = "nursing_uc7_8"
    const val NursingUC9 = "nursing_uc9"
    const val NursingUC10 = "nursing_uc10"
    //neuro
    const val NeuroCaseTasks = "neuro_case_tasks"
    const val NeuroUC1 = "neuro_uc1"
    const val NeuroUC5 = "neuro_uc5"
    //lo del admision
    const val AdmissionCaseTasks = "admission_case_tasks"
    const val AdmissionUC12 = "admission_uc12"
    const val ClosedCasesNeuro = "closed_cases_neuro"
    const val ClosedCasesNursing = "closed_cases_nursing"
    const val ClosedCasesAdmission = "closed_cases_admission"
    const val ClosedCaseDetail = "closed_case_detail"







}
