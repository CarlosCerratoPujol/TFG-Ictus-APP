package com.example.ictusapp.ui.screens.nursing

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.NavHostController
import com.example.ictusapp.data.CaseRepository
import com.example.ictusapp.data.TaskItem
import com.example.ictusapp.ui.components.NursingLayout
import com.example.ictusapp.ui.navigation.Routes
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ListenerRegistration

private val TASK_ORDER = listOf(
    "UC1", "UC2", "UC3_4", "UC5", "UC6", "UC7_8", "UC9", "UC10", "UC11", "UC12"
)

private fun nextVisibleTasks(
    allTasks: List<TaskItem>,
    allowedCodesForRole: Set<String>
): List<TaskItem> {

    val byCode = allTasks.associateBy { it.code }

    val firstPendingCode = TASK_ORDER.firstOrNull { code ->
        val t = byCode[code]
        t == null || t.done == false
    }

    if (firstPendingCode == null) {
        return allTasks
            .filter { it.code in allowedCodesForRole && it.done }
            .sortedBy { TASK_ORDER.indexOf(it.code) }
    }

    val completed = allTasks.filter { it.code in allowedCodesForRole && it.done }
    val next = allTasks.firstOrNull { it.code == firstPendingCode && it.code in allowedCodesForRole }

    val result = if (next != null) completed + next else completed
    return result.sortedBy { TASK_ORDER.indexOf(it.code) }
}

@Composable
fun NursingCaseTasksScreen(navController: NavHostController, caseId: String) {

    val repo = remember { CaseRepository() }
    val db = FirebaseFirestore.getInstance()

    var tasks by remember { mutableStateOf<List<TaskItem>>(emptyList()) }
    var error by remember { mutableStateOf<String?>(null) }

    var tasksReg by remember { mutableStateOf<ListenerRegistration?>(null) }
    var caseReg by remember { mutableStateOf<ListenerRegistration?>(null) }

    var adverseEvent by remember { mutableStateOf(false) }
    var thromboCancelled by remember { mutableStateOf(false) }

    DisposableEffect(caseId) {
        tasksReg = repo.listenTasksForCase(
            caseId = caseId,
            onUpdate = { tasks = it },
            onErr = { error = it }
        )

        caseReg = db.collection("cases").document(caseId)
            .addSnapshotListener { snap, _ ->
                if (snap != null && snap.exists()) {
                    adverseEvent = snap.getBoolean("adverseEvent") ?: false
                    thromboCancelled = snap.getBoolean("thrombolysisCancelled") ?: false
                }
            }

        onDispose {
            tasksReg?.remove()
            caseReg?.remove()
        }
    }

    fun goToTask(code: String) {
        val base = when (code) {
            "UC2" -> Routes.NursingUC2
            "UC3_4" -> Routes.NursingUC3_4
            "UC6" -> Routes.NursingUC6
            "UC7_8" -> Routes.NursingUC7_8
            "UC9" -> Routes.NursingUC9
            "UC10" -> Routes.NursingUC10
            else -> null
        }
        if (base != null) navController.navigate(base + "/$caseId")
    }

    val normalCodes = setOf("UC2", "UC3_4", "UC6", "UC7_8", "UC9", "UC10")
    val cancelledCodes = setOf("UC2", "UC3_4")

    val visibleTasks = when {
        adverseEvent -> tasks.filter { it.code == "UC10" }
        thromboCancelled -> nextVisibleTasks(tasks, cancelledCodes)
        else -> nextVisibleTasks(tasks, normalCodes)
    }

    // 🧱 LAYOUT CONSISTENTE
    NursingLayout(
        title = "Flujo clínico",
        navController = navController,
        currentRoute = Routes.NursingHome
    ) { modifier ->

        Column(modifier = modifier.fillMaxSize()) {

            // 🚨 ALERTAS CLÍNICAS
            if (adverseEvent) {
                Card(
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.errorContainer
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp)
                ) {
                    Text(
                        "⚠️ Evento adverso: completar UC10 inmediatamente",
                        modifier = Modifier.padding(16.dp)
                    )
                }
            } else if (thromboCancelled) {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp)
                ) {
                    Text(
                        "⚠️ Trombólisis cancelada (solo UC2 y UC3_4)",
                        modifier = Modifier.padding(16.dp)
                    )
                }
            }

            // ❌ ERROR
            error?.let {
                Text(
                    it,
                    color = MaterialTheme.colorScheme.error,
                    modifier = Modifier.padding(16.dp)
                )
            }

            if (visibleTasks.isEmpty()) {
                Text("No hay tareas disponibles", modifier = Modifier.padding(16.dp))
                return@Column
            }

            // 📋 LISTA
            LazyColumn(
                contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp)
            ) {
                items(visibleTasks, key = { it.code }) { t ->

                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 12.dp),
                        elevation = CardDefaults.cardElevation(4.dp)
                    ) {
                        Column(Modifier.padding(16.dp)) {

                            Text(
                                "${t.code} — ${t.title}",
                                style = MaterialTheme.typography.titleMedium
                            )

                            Spacer(Modifier.height(6.dp))

                            Text(
                                if (t.done) "✅ Completada" else "⏳ Pendiente",
                                style = MaterialTheme.typography.bodySmall
                            )

                            Spacer(Modifier.height(10.dp))

                            Button(
                                onClick = { goToTask(t.code) },
                                enabled = !t.done,
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text("Abrir tarea")
                            }
                        }
                    }
                }
            }
        }
    }
}
