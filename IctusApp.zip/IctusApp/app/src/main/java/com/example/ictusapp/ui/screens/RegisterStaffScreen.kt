package com.example.ictusapp.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.navigation.NavHostController
import com.example.ictusapp.data.AuthRepository
import com.example.ictusapp.data.CaseRepository
import com.example.ictusapp.data.UserRepository
import com.example.ictusapp.ui.navigation.Routes

@Composable
fun RegisterStaffScreen(navController: NavHostController) {

    val auth = AuthRepository()
    val userRepo = UserRepository()

    var email by remember { mutableStateOf("") }
    var pass by remember { mutableStateOf("") }

    var loading by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }

    Box(
        modifier = Modifier.fillMaxSize()
    ) {

        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(24.dp),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {

            Text(
                "Registro de personal",
                style = MaterialTheme.typography.headlineMedium
            )

            Spacer(Modifier.height(24.dp))

            Card(
                shape = RoundedCornerShape(20.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .shadow(8.dp)
            ) {
                Column(
                    Modifier
                        .padding(20.dp)
                        .fillMaxWidth()
                ) {

                    OutlinedTextField(
                        value = email,
                        onValueChange = { email = it },
                        label = { Text("Email") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )

                    Spacer(Modifier.height(12.dp))

                    OutlinedTextField(
                        value = pass,
                        onValueChange = { pass = it },
                        label = { Text("Contraseña") },
                        visualTransformation = PasswordVisualTransformation(),
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )

                    error?.let {
                        Spacer(Modifier.height(10.dp))
                        Text(it, color = MaterialTheme.colorScheme.error)
                    }

                    Spacer(Modifier.height(16.dp))

                    Button(
                        onClick = {

                            val e = email.trim()

                            if (e.isBlank() || pass.length < 6) {
                                error = "Email válido y contraseña (mín. 6)"
                                return@Button
                            }

                            loading = true
                            error = null

                            auth.register(e, pass,
                                onOk = { uid ->

                                    if (uid.isBlank()) {
                                        loading = false
                                        error = "Error interno"
                                        return@register
                                    }

                                    userRepo.findStaffRoleByEmail(
                                        email = e,
                                        onOk = { role ->

                                            if (role == null) {

                                                auth.deleteCurrentUser(
                                                    onOk = {
                                                        auth.logout()
                                                        loading = false
                                                        error = "No autorizado. Contacta con ADMIN."
                                                    },
                                                    onErr = {
                                                        loading = false
                                                        error = "No autorizado."
                                                    }
                                                )

                                            } else {

                                                userRepo.setUserRole(
                                                    uid = uid,
                                                    email = e,
                                                    role = role,
                                                    onOk = {
                                                        loading = false

                                                        val dest = when (role) {
                                                            CaseRepository.ROLE_ADMISSION -> Routes.AdmissionHome
                                                            CaseRepository.ROLE_NEURO -> Routes.NeuroHome
                                                            CaseRepository.ROLE_NURSING -> Routes.NursingHome
                                                            else -> Routes.Login
                                                        }

                                                        navController.navigate(dest) {
                                                            popUpTo(Routes.Login) { inclusive = true }
                                                        }
                                                    },
                                                    onErr = {
                                                        loading = false
                                                        error = it
                                                    }
                                                )
                                            }
                                        },
                                        onErr = {
                                            loading = false
                                            error = it
                                        }
                                    )
                                },
                                onErr = {
                                    loading = false
                                    error = it
                                }
                            )
                        },
                        enabled = !loading,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(if (loading) "Creando..." else "Crear cuenta")
                    }

                    Spacer(Modifier.height(8.dp))

                    TextButton(
                        onClick = { navController.popBackStack() },
                        modifier = Modifier.align(Alignment.CenterHorizontally)
                    ) {
                        Text("Volver al login")
                    }
                }
            }
        }
    }
}
