package com.example.ictusapp.ui.screens.nursing

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.NavHostController
import com.example.ictusapp.data.AuthRepository
import com.example.ictusapp.data.CaseRepository
import com.example.ictusapp.ui.components.NursingLayout
import com.example.ictusapp.ui.navigation.Routes

@Composable
fun NursingUC10StopInfusionScreen(navController: NavHostController, caseId: String) {

    val repo = remember { CaseRepository() }
    val auth = remember { AuthRepository() }

    var reason by remember { mutableStateOf("") }
    var actions by remember { mutableStateOf("") }
    var notified by remember { mutableStateOf(false) }

    var loading by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }

    NursingLayout(
        title = "UC10 — Interrupción de perfusión",
        navController = navController,
        currentRoute = Routes.NursingHome
    ) { modifier ->

        Column(
            modifier = modifier
                .fillMaxSize()
                .padding(16.dp)
        ) {

            // 🚨 ALERTA CLÍNICA
            Card(
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.errorContainer
                ),
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    "⚠️ Evento adverso detectado. Proceder con interrupción del tratamiento.",
                    modifier = Modifier.padding(16.dp)
                )
            }

            Spacer(Modifier.height(16.dp))

            // 🟦 MOTIVO
            Card(modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp)) {

                    Text("🧠 Motivo clínico", style = MaterialTheme.typography.titleMedium)

                    Spacer(Modifier.height(12.dp))

                    OutlinedTextField(
                        value = reason,
                        onValueChange = { reason = it },
                        label = { Text("Motivo de interrupción") },
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }

            Spacer(Modifier.height(16.dp))

            // 🟦 ACCIONES
            Card(modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp)) {

                    Text("🩺 Actuaciones realizadas", style = MaterialTheme.typography.titleMedium)

                    Spacer(Modifier.height(12.dp))

                    OutlinedTextField(
                        value = actions,
                        onValueChange = { actions = it },
                        label = { Text("Acciones realizadas") },
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }

            Spacer(Modifier.height(16.dp))

            // 🟦 NOTIFICACIÓN
            Card(modifier = Modifier.fillMaxWidth()) {
                Row(
                    Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("Equipo notificado")
                    Switch(
                        checked = notified,
                        onCheckedChange = { notified = it }
                    )
                }
            }

            Spacer(Modifier.height(16.dp))

            // ❌ ERROR
            error?.let {
                Text(it, color = MaterialTheme.colorScheme.error)
            }

            Spacer(Modifier.height(16.dp))

            // 🚀 BOTÓN
            Button(
                onClick = {

                    if (reason.isBlank()) {
                        error = "Indica el motivo clínico"
                        return@Button
                    }

                    loading = true
                    error = null

                    repo.completeTask(
                        caseId = caseId,
                        taskCode = "UC10",
                        data = mapOf(
                            "reason" to reason.trim(),
                            "actionsTaken" to actions.trim(),
                            "notifiedTeam" to notified,
                            "adverseEventFlow" to true
                        ),
                        onOk = {

                            repo.closeCaseAdverse(
                                caseId = caseId,
                                closedByUid = auth.currentUid() ?: "unknown",
                                onOk = {
                                    loading = false
                                    navController.navigate(Routes.NursingHome) {
                                        popUpTo(Routes.NursingHome) { inclusive = true }
                                    }
                                },
                                onErr = {
                                    loading = false
                                    error = it
                                }
                            )
                        },
                        onErr = {
                            loading = false
                            error = it
                        }
                    )
                },
                enabled = !loading,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(if (loading) "Cerrando..." else "Finalizar evento adverso")
            }
        }
    }
}

