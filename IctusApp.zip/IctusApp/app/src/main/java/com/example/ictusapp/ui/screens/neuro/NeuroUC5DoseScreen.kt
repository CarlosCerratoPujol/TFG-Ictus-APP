package com.example.ictusapp.ui.screens.neuro

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.NavHostController
import com.example.ictusapp.data.CaseRepository
import com.example.ictusapp.ui.components.NeuroLayout
import com.example.ictusapp.ui.navigation.Routes
import kotlin.math.round

@Composable
fun NeuroUC5DoseScreen(navController: NavHostController, caseId: String) {

    val repo = CaseRepository()

    var weight by remember { mutableStateOf("") }
    var loading by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }

    val w = weight.replace(",", ".").toDoubleOrNull()

    val total = if (w != null) w * 0.9 else null
    val bolus = if (total != null) total * 0.10 else null
    val infusion = if (total != null) total * 0.90 else null

    fun r(x: Double) = (round(x * 100) / 100.0)

    NeuroLayout(
        title = "UC5 — Cálculo de dosis",
        navController = navController,
        currentRoute = Routes.NeuroHome
    ) { modifier ->

        Column(
            modifier = modifier
                .fillMaxSize()
                .padding(16.dp)
        ) {

            // 🟦 TARJETA INPUT
            Card(
                elevation = CardDefaults.cardElevation(6.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(Modifier.padding(16.dp)) {

                    Text("💉 Datos del paciente", style = MaterialTheme.typography.titleMedium)

                    Spacer(Modifier.height(12.dp))

                    OutlinedTextField(
                        value = weight,
                        onValueChange = { weight = it },
                        label = { Text("Peso (kg)") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }

            Spacer(Modifier.height(16.dp))

            // 🟦 RESULTADOS
            Card(
                elevation = CardDefaults.cardElevation(6.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(Modifier.padding(16.dp)) {

                    Text("📊 Dosis calculada", style = MaterialTheme.typography.titleMedium)

                    Spacer(Modifier.height(12.dp))

                    if (total != null) {
                        Text("Total: ${r(total)} mg")
                        Text("Bolo (10%): ${r(bolus!!)} mg")
                        Text("Perfusión (90%): ${r(infusion!!)} mg")
                    } else {
                        Text("Introduce el peso para calcular")
                    }
                }
            }

            Spacer(Modifier.height(16.dp))

            // ❌ ERROR
            error?.let {
                Text(it, color = MaterialTheme.colorScheme.error)
            }

            Spacer(Modifier.height(16.dp))

            // 🚀 BOTÓN
            Button(
                onClick = {
                    if (w == null || w <= 0) {
                        error = "Peso inválido"
                        return@Button
                    }

                    val totalMg = w * 0.9
                    val bolusMg = totalMg * 0.10
                    val infusionMg = totalMg * 0.90

                    loading = true
                    error = null

                    repo.completeTask(
                        caseId = caseId,
                        taskCode = "UC5",
                        data = mapOf(
                            "weightKg" to w,
                            "totalDoseMg" to totalMg,
                            "bolusMg" to bolusMg,
                            "infusionMg" to infusionMg,
                            "bolusDoseMg" to bolusMg,
                            "infusionDoseMg" to infusionMg
                        ),
                        onOk = {
                            loading = false
                            navController.popBackStack()
                        },
                        onErr = {
                            loading = false
                            error = it
                        }
                    )
                },
                enabled = !loading && total != null,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(if (loading) "Guardando..." else "Confirmar dosis")
            }
        }
    }
}
