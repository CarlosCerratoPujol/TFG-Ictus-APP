package com.example.ictusapp.ui.screens.neuro

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.NavHostController
import com.example.ictusapp.data.CaseRepository
import com.example.ictusapp.data.TaskItem
import com.example.ictusapp.ui.components.NeuroLayout
import com.example.ictusapp.ui.navigation.Routes
import com.google.firebase.firestore.ListenerRegistration

private val TASK_ORDER = listOf(
    "UC1", "UC2", "UC3_4", "UC5", "UC6", "UC7_8", "UC9", "UC10", "UC11", "UC12"
)

private fun nextVisibleTasks(
    allTasks: List<TaskItem>,
    allowedCodesForRole: Set<String>
): List<TaskItem> {

    val byCode = allTasks.associateBy { it.code }

    val firstPendingCode = TASK_ORDER.firstOrNull { code ->
        val t = byCode[code]
        t == null || t.done == false
    }

    if (firstPendingCode == null) {
        return allTasks
            .filter { it.code in allowedCodesForRole && it.done }
            .sortedBy { TASK_ORDER.indexOf(it.code) }
    }

    val completed = allTasks.filter { it.code in allowedCodesForRole && it.done }
    val next = allTasks.firstOrNull { it.code == firstPendingCode && it.code in allowedCodesForRole }

    val result = if (next != null) completed + next else completed
    return result.sortedBy { TASK_ORDER.indexOf(it.code) }
}

@Composable
fun NeuroCaseTasksScreen(navController: NavHostController, caseId: String) {

    val repo = CaseRepository()

    var tasks by remember { mutableStateOf<List<TaskItem>>(emptyList()) }
    var error by remember { mutableStateOf<String?>(null) }
    var reg by remember { mutableStateOf<ListenerRegistration?>(null) }

    DisposableEffect(caseId) {
        reg = repo.listenTasksForCase(
            caseId = caseId,
            onUpdate = { tasks = it },
            onErr = { error = it }
        )
        onDispose { reg?.remove() }
    }

    val neuroCodes = setOf("UC1", "UC5")
    val neuroTasks = nextVisibleTasks(tasks, neuroCodes)

    fun goTo(code: String) {
        val base = when (code) {
            "UC1" -> Routes.NeuroUC1
            "UC5" -> Routes.NeuroUC5
            else -> null
        }
        if (base != null) navController.navigate(base + "/$caseId")
    }

    // 🧱 LAYOUT CONSISTENTE
    NeuroLayout(
        title = "Flujo clínico",
        navController = navController,
        currentRoute = Routes.NeuroHome
    ) { modifier ->

        Column(modifier = modifier.fillMaxSize()) {

            // ❌ Error
            error?.let {
                Text(
                    it,
                    color = MaterialTheme.colorScheme.error,
                    modifier = Modifier.padding(16.dp)
                )
            }

            // 📊 CABECERA (muy pro)
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                elevation = CardDefaults.cardElevation(4.dp)
            ) {
                Column(Modifier.padding(16.dp)) {
                    Text("🧠 Evaluación clínica", style = MaterialTheme.typography.titleMedium)
                    Text("Decisiones médicas del caso")
                }
            }

            // 📋 LISTA
            LazyColumn(
                contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp)
            ) {
                items(neuroTasks, key = { it.code }) { t ->

                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 12.dp),
                        elevation = CardDefaults.cardElevation(4.dp)
                    ) {
                        Column(Modifier.padding(16.dp)) {

                            Text(
                                text = "${t.code} — ${t.title}",
                                style = MaterialTheme.typography.titleMedium
                            )

                            Spacer(Modifier.height(6.dp))

                            Text(
                                text = if (t.done) "✅ Completada" else "⏳ Pendiente",
                                style = MaterialTheme.typography.bodySmall
                            )

                            Spacer(Modifier.height(10.dp))

                            Button(
                                onClick = { goTo(t.code) },
                                enabled = !t.done,
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text("Abrir evaluación")
                            }
                        }
                    }
                }
            }
        }
    }
}