package com.example.ictusapp.ui.screens.nursing

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.NavHostController
import com.example.ictusapp.data.AuthRepository
import com.example.ictusapp.data.CaseRepository
import com.example.ictusapp.ui.components.NursingLayout
import com.example.ictusapp.ui.navigation.Routes
import kotlinx.coroutines.delay

@Composable
fun NursingUC9ControlsScreen(
    navController: NavHostController,
    caseId: String
) {
    val repo = CaseRepository()
    val auth = AuthRepository()

    var controlIndex by remember { mutableStateOf(1) }
    var waitingNext by remember { mutableStateOf(false) }

    var nihss by remember { mutableStateOf("") }
    var sbp by remember { mutableStateOf("") }
    var dbp by remember { mutableStateOf("") }
    var notes by remember { mutableStateOf("") }

    var adverse by remember { mutableStateOf(false) }
    var adverseReason by remember { mutableStateOf("") }

    var loading by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }

    var goToUc10 by remember { mutableStateOf(false) }

    LaunchedEffect(goToUc10) {
        if (goToUc10) {
            navController.navigate(Routes.NursingUC10 + "/$caseId") {
                popUpTo(Routes.NursingUC9 + "/$caseId") { inclusive = true }
            }
        }
    }

    LaunchedEffect(waitingNext, controlIndex) {
        if (waitingNext) {
            delay(5000)
            waitingNext = false
            controlIndex += 1
        }
    }

    fun clearForm() {
        nihss = ""
        sbp = ""
        dbp = ""
        notes = ""
        adverse = false
        adverseReason = ""
    }

    fun finishWithError(msg: String) {
        loading = false
        error = msg
    }

    NursingLayout(
        title = "UC9 — Monitorización",
        navController = navController,
        currentRoute = Routes.NursingHome
    ) { modifier ->

        Column(
            modifier = modifier
                .fillMaxSize()
                .padding(16.dp)
        ) {
            Card(modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp)) {
                    Text("📊 Control ${controlIndex.coerceAtMost(3)} / 3")
                    if (waitingNext) {
                        Spacer(Modifier.height(6.dp))
                        Text("⏳ Esperando siguiente medición...")
                    }
                }
            }

            Spacer(Modifier.height(16.dp))

            if (controlIndex > 3) {
                Text("✅ Monitorización completada")
                Spacer(Modifier.height(12.dp))
                TextButton(onClick = { navController.popBackStack() }) {
                    Text("Volver")
                }
                return@Column
            }

            Card(modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp)) {
                    Text("🧠 Parámetros clínicos", style = MaterialTheme.typography.titleMedium)

                    Spacer(Modifier.height(12.dp))

                    OutlinedTextField(
                        value = nihss,
                        onValueChange = { nihss = it },
                        label = { Text("NIHSS") },
                        modifier = Modifier.fillMaxWidth(),
                        enabled = !loading && !waitingNext
                    )

                    Spacer(Modifier.height(8.dp))

                    OutlinedTextField(
                        value = sbp,
                        onValueChange = { sbp = it },
                        label = { Text("SBP") },
                        modifier = Modifier.fillMaxWidth(),
                        enabled = !loading && !waitingNext
                    )

                    Spacer(Modifier.height(8.dp))

                    OutlinedTextField(
                        value = dbp,
                        onValueChange = { dbp = it },
                        label = { Text("DBP") },
                        modifier = Modifier.fillMaxWidth(),
                        enabled = !loading && !waitingNext
                    )

                    Spacer(Modifier.height(8.dp))

                    OutlinedTextField(
                        value = notes,
                        onValueChange = { notes = it },
                        label = { Text("Notas") },
                        modifier = Modifier.fillMaxWidth(),
                        enabled = !loading && !waitingNext
                    )
                }
            }

            Spacer(Modifier.height(16.dp))

            Card(modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp)) {
                    Row(
                        Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("⚠️ Evento adverso")
                        Switch(
                            checked = adverse,
                            onCheckedChange = { adverse = it },
                            enabled = !loading && !waitingNext
                        )
                    }

                    if (adverse) {
                        Spacer(Modifier.height(8.dp))
                        OutlinedTextField(
                            value = adverseReason,
                            onValueChange = { adverseReason = it },
                            label = { Text("Descripción") },
                            modifier = Modifier.fillMaxWidth(),
                            enabled = !loading && !waitingNext
                        )
                    }
                }
            }

            Spacer(Modifier.height(16.dp))

            error?.let {
                Text(it, color = MaterialTheme.colorScheme.error)
                Spacer(Modifier.height(16.dp))
            }

            Button(
                onClick = {
                    val n = nihss.toIntOrNull()
                    val s = sbp.toIntOrNull()
                    val d = dbp.toIntOrNull()

                    if (n == null || s == null || d == null) {
                        error = "Valores inválidos"
                        return@Button
                    }

                    if (adverse && adverseReason.isBlank()) {
                        error = "Describe el evento adverso"
                        return@Button
                    }

                    loading = true
                    error = null

                    repo.addControl(
                        caseId = caseId,
                        controlData = mapOf(
                            "index" to controlIndex,
                            "nihss" to n,
                            "sbp" to s,
                            "dbp" to d,
                            "notes" to notes.trim(),
                            "adverse" to adverse,
                            "adverseReason" to adverseReason.trim()
                        ),
                        onOk = {
                            if (adverse) {
                                // Flujo con evento adverso: marcar caso y pasar a UC10 manual
                                repo.markAdverseEvent(
                                    caseId = caseId,
                                    reason = adverseReason.trim(),
                                    byUid = auth.currentUid() ?: "unknown",
                                    onOk = {
                                        repo.completeTask(
                                            caseId = caseId,
                                            taskCode = "UC9",
                                            data = mapOf(
                                                "endedByAdverseEvent" to true,
                                                "controlIndex" to controlIndex
                                            ),
                                            onOk = {
                                                loading = false
                                                clearForm()
                                                goToUc10 = true
                                            },
                                            onErr = { finishWithError(it) }
                                        )
                                    },
                                    onErr = { finishWithError(it) }
                                )
                            } else {
                                // Flujo normal
                                clearForm()

                                if (controlIndex < 3) {
                                    loading = false
                                    waitingNext = true
                                } else {
                                    // 3er control sin evento adverso:
                                    // completar UC9 y auto-completar UC10
                                    repo.completeTask(
                                        caseId = caseId,
                                        taskCode = "UC9",
                                        data = mapOf(
                                            "controlsCount" to 3,
                                            "endedByAdverseEvent" to false
                                        ),
                                        onOk = {
                                            repo.completeTask(
                                                caseId = caseId,
                                                taskCode = "UC10",
                                                data = mapOf(
                                                    "autoCompletedNoAdverseEvent" to true,
                                                    "reason" to "Sin evento adverso",
                                                    "actionsTaken" to "No procede interrumpir perfusión",
                                                    "notifiedTeam" to false
                                                ),
                                                onOk = {
                                                    loading = false
                                                    // Volver a la lista de tareas del caso.
                                                    // UC10 ya no quedará pendiente y el flujo seguirá.
                                                    navController.popBackStack()
                                                },
                                                onErr = { finishWithError(it) }
                                            )
                                        },
                                        onErr = { finishWithError(it) }
                                    )
                                }
                            }
                        },
                        onErr = { finishWithError(it) }
                    )
                },
                enabled = !loading && !waitingNext,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(if (loading) "Guardando..." else "Registrar control")
            }
        }
    }
}
