package com.example.ictusapp.ui.navigation

import androidx.compose.runtime.*
import androidx.navigation.NavHostController
import androidx.navigation.NavType
import androidx.navigation.compose.*
import androidx.navigation.navArgument
import com.example.ictusapp.ui.screens.*
import com.example.ictusapp.ui.screens.admin.*
import com.example.ictusapp.ui.screens.admission.*
import com.example.ictusapp.ui.screens.neuro.*
import com.example.ictusapp.ui.screens.nursing.*
import com.example.ictusapp.ui.screens.common.*

@Composable
fun AppNavGraph(navController: NavHostController) {

    NavHost(navController = navController, startDestination = Routes.Splash) {

        // -------------------------
        // AUTH
        // -------------------------
        composable(Routes.Splash) { SplashScreen(navController) }
        composable(Routes.Login) { LoginScreen(navController) }
        composable(Routes.RegisterStaff) { RegisterStaffScreen(navController) }

        // -------------------------
        // ADMIN
        // -------------------------
        composable(Routes.AdminHome) { AdminHomeScreen(navController) }
        composable(Routes.AdminUsers) { AdminUsersScreen(navController) }
        composable(Routes.AdminCreateUser) { AdminCreateUserScreen(navController) }

        // -------------------------
        // HOMES
        // -------------------------
        composable(Routes.NeuroHome) { NeuroHomeScreen(navController) }
        composable(Routes.NursingHome) { NursingHomeScreen(navController) }
        composable(Routes.AdmissionHome) { AdmissionHomeScreen(navController) }

        // -------------------------
        // ADMISIÓN
        // -------------------------
        composable(Routes.AdmissionCreateCase) {
            AdmissionCreateCaseScreen(navController)
        }

        composable(
            Routes.AdmissionCaseTasks + "/{caseId}",
            arguments = listOf(navArgument("caseId") { type = NavType.StringType })
        ) {
            val caseId = it.arguments?.getString("caseId")!!
            AdmissionCaseTasksScreen(navController, caseId)
        }

        composable(
            Routes.AdmissionUC12 + "/{caseId}",
            arguments = listOf(navArgument("caseId") { type = NavType.StringType })
        ) {
            val caseId = it.arguments?.getString("caseId")!!
            AdmissionUC12CloseCaseScreen(navController, caseId)
        }

        // -------------------------
        // NEURO
        // -------------------------
        composable(
            Routes.NeuroCaseTasks + "/{caseId}",
            arguments = listOf(navArgument("caseId") { type = NavType.StringType })
        ) {
            val caseId = it.arguments?.getString("caseId")!!
            NeuroCaseTasksScreen(navController, caseId)
        }

        composable(
            Routes.NeuroUC1 + "/{caseId}",
            arguments = listOf(navArgument("caseId") { type = NavType.StringType })
        ) {
            val caseId = it.arguments?.getString("caseId")!!
            NeuroUC1EligibilityScreen(navController, caseId)
        }

        composable(
            Routes.NeuroUC5 + "/{caseId}",
            arguments = listOf(navArgument("caseId") { type = NavType.StringType })
        ) {
            val caseId = it.arguments?.getString("caseId")!!
            NeuroUC5DoseScreen(navController, caseId)
        }

        // -------------------------
        // NURSING
        // -------------------------
        composable(
            Routes.NursingCaseTasks + "/{caseId}",
            arguments = listOf(navArgument("caseId") { type = NavType.StringType })
        ) {
            val caseId = it.arguments?.getString("caseId")!!
            NursingCaseTasksScreen(navController, caseId)
        }

        composable(
            Routes.NursingUC2 + "/{caseId}",
            arguments = listOf(navArgument("caseId") { type = NavType.StringType })
        ) {
            val caseId = it.arguments?.getString("caseId")!!
            NursingUC2WeightScreen(navController, caseId)
        }

        composable(
            Routes.NursingUC3_4 + "/{caseId}",
            arguments = listOf(navArgument("caseId") { type = NavType.StringType })
        ) {
            val caseId = it.arguments?.getString("caseId")!!
            NursingUC34VitalsScreen(navController, caseId)
        }

        composable(
            Routes.NursingUC6 + "/{caseId}",
            arguments = listOf(navArgument("caseId") { type = NavType.StringType })
        ) {
            val caseId = it.arguments?.getString("caseId")!!
            NursingUC6DoubleCheckScreen(navController, caseId)
        }

        composable(
            Routes.NursingUC7_8 + "/{caseId}",
            arguments = listOf(navArgument("caseId") { type = NavType.StringType })
        ) {
            val caseId = it.arguments?.getString("caseId")!!
            NursingUC78AdministrationScreen(navController, caseId)
        }

        composable(
            Routes.NursingUC9 + "/{caseId}",
            arguments = listOf(navArgument("caseId") { type = NavType.StringType })
        ) {
            val caseId = it.arguments?.getString("caseId")!!
            NursingUC9ControlsScreen(navController, caseId)
        }

        composable(
            Routes.NursingUC10 + "/{caseId}",
            arguments = listOf(navArgument("caseId") { type = NavType.StringType })
        ) {
            val caseId = it.arguments?.getString("caseId")!!
            NursingUC10StopInfusionScreen(navController, caseId)
        }

        // -------------------------
        // HISTÓRICO POR ROL
        // -------------------------

        // 🧠 NEURO
        composable(Routes.ClosedCasesNeuro) {
            ClosedCasesScreen(navController, role = "NEURO")
        }

        // 💉 ENFERMERÍA
        composable(Routes.ClosedCasesNursing) {
            ClosedCasesScreen(navController, role = "NURSING")
        }

        // 🏥 ADMISIÓN
        composable(Routes.ClosedCasesAdmission) {
            ClosedCasesScreen(navController, role = "ADMISSION")
        }

        // -------------------------
        // DETALLE (CON ROL 🔥)
        // -------------------------
        composable(
            route = Routes.ClosedCaseDetail + "/{caseId}/{role}",
            arguments = listOf(
                navArgument("caseId") { type = NavType.StringType },
                navArgument("role") { type = NavType.StringType }
            )
        ) {
            val caseId = it.arguments?.getString("caseId")!!
            val role = it.arguments?.getString("role")!!

            ClosedCaseDetailScreen(
                navController = navController,
                caseId = caseId,
                role = role
            )
        }
    }
}