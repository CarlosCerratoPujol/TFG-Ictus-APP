package com.example.ictusapp.ui.screens

import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.navigation.NavHostController
import com.example.ictusapp.data.AuthRepository
import com.example.ictusapp.data.CaseRepository
import com.example.ictusapp.data.UserRepository
import com.example.ictusapp.ui.navigation.Routes

@Composable
fun SplashScreen(navController: NavHostController) {
    val authRepo = AuthRepository()
    val userRepo = UserRepository()

    LaunchedEffect(Unit) {
        val uid = authRepo.currentUid()
        val email = authRepo.currentEmail()

        if (uid == null) {
            navController.navigate(Routes.Login) {
                popUpTo(Routes.Splash) { inclusive = true }
            }
            return@LaunchedEffect
        }

        userRepo.getUserRole(
            uid = uid,
            onOk = { roleStr ->
                if (!roleStr.isNullOrBlank()) {
                    val dest = when (roleStr) {
                        "ADMIN" -> Routes.AdminHome
                        "NEURO" -> Routes.NeuroHome
                        "NURSING" -> Routes.NursingHome
                        "ADMISSION" -> Routes.AdmissionHome
                        else -> Routes.Login
                    }
                    navController.navigate(dest) {
                        popUpTo(Routes.Splash) { inclusive = true }
                    }
                } else {
                    // Si no hay rol todavía, intentamos auto-enlazar con staff por email
                    if (email.isNullOrBlank()) {
                        navController.navigate(Routes.Login) {
                            popUpTo(Routes.Splash) { inclusive = true }
                        }
                        return@getUserRole
                    }

                    userRepo.findStaffRoleByEmail(
                        email = email,
                        onOk = { staffRole ->
                            if (staffRole == null) {
                                authRepo.logout()
                                navController.navigate(Routes.Login) {
                                    popUpTo(Routes.Splash) { inclusive = true }
                                }
                            } else {
                                userRepo.setUserRole(
                                    uid = uid,
                                    email = email,
                                    role = staffRole,
                                    onOk = {
                                        val dest = when (staffRole) {
                                            CaseRepository.ROLE_ADMISSION -> Routes.AdmissionHome
                                            CaseRepository.ROLE_NEURO -> Routes.NeuroHome
                                            CaseRepository.ROLE_NURSING -> Routes.NursingHome
                                            else -> Routes.Login
                                        }
                                        navController.navigate(dest) {
                                            popUpTo(Routes.Splash) { inclusive = true }
                                        }
                                    },
                                    onErr = {
                                        authRepo.logout()
                                        navController.navigate(Routes.Login) {
                                            popUpTo(Routes.Splash) { inclusive = true }
                                        }
                                    }
                                )
                            }
                        },
                        onErr = {
                            authRepo.logout()
                            navController.navigate(Routes.Login) {
                                popUpTo(Routes.Splash) { inclusive = true }
                            }
                        }
                    )
                }
            },
            onErr = {
                authRepo.logout()
                navController.navigate(Routes.Login) {
                    popUpTo(Routes.Splash) { inclusive = true }
                }
            }
        )
    }

    Text("Cargando…")
}



