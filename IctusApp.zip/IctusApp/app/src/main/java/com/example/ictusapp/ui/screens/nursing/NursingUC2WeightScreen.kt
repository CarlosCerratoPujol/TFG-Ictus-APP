package com.example.ictusapp.ui.screens.nursing

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.NavHostController
import com.example.ictusapp.data.CaseRepository
import com.example.ictusapp.ui.components.NursingLayout
import com.example.ictusapp.ui.navigation.Routes

@Composable
fun NursingUC2WeightScreen(navController: NavHostController, caseId: String) {

    val repo = CaseRepository()

    var weight by remember { mutableStateOf("") }
    var estimated by remember { mutableStateOf(false) }

    var loading by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }

    NursingLayout(
        title = "UC2 — Peso del paciente",
        navController = navController,
        currentRoute = Routes.NursingHome
    ) { modifier ->

        Column(
            modifier = modifier
                .fillMaxSize()
                .padding(16.dp)
        ) {

            // 🟦 TARJETA PESO
            Card(
                elevation = CardDefaults.cardElevation(6.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(Modifier.padding(16.dp)) {

                    Text("⚖️ Registro de peso", style = MaterialTheme.typography.titleMedium)

                    Spacer(Modifier.height(12.dp))

                    OutlinedTextField(
                        value = weight,
                        onValueChange = { weight = it },
                        label = { Text("Peso (kg)") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )

                    Spacer(Modifier.height(12.dp))

                    Row(
                        Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("Peso estimado")
                        Switch(
                            checked = estimated,
                            onCheckedChange = { estimated = it }
                        )
                    }
                }
            }

            Spacer(Modifier.height(16.dp))

            // 🟦 INFO CLÍNICA (muy pro)
            Card(
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(Modifier.padding(16.dp)) {
                    Text("ℹ️ Información", style = MaterialTheme.typography.titleMedium)

                    Spacer(Modifier.height(8.dp))

                    Text("El peso es necesario para el cálculo de la dosis de alteplasa.")
                }
            }

            Spacer(Modifier.height(16.dp))

            // ❌ ERROR
            error?.let {
                Text(it, color = MaterialTheme.colorScheme.error)
            }

            Spacer(Modifier.height(16.dp))

            // 🚀 BOTÓN
            Button(
                onClick = {
                    val w = weight.replace(",", ".").toDoubleOrNull()

                    if (w == null || w <= 0) {
                        error = "Introduce un peso válido"
                        return@Button
                    }

                    loading = true
                    error = null

                    repo.completeTask(
                        caseId = caseId,
                        taskCode = "UC2",
                        data = mapOf(
                            "weightKg" to w,
                            "estimated" to estimated
                        ),
                        onOk = {
                            loading = false
                            navController.popBackStack()
                        },
                        onErr = {
                            loading = false
                            error = it
                        }
                    )
                },
                enabled = !loading,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(if (loading) "Guardando..." else "Guardar peso")
            }
        }
    }
}
