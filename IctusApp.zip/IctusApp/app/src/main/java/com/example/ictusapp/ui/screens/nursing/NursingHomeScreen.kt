package com.example.ictusapp.ui.screens.nursing

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.NavHostController
import com.example.ictusapp.data.CaseItem
import com.example.ictusapp.data.CaseRepository
import com.example.ictusapp.ui.components.NursingLayout
import com.example.ictusapp.ui.navigation.Routes
import com.google.firebase.firestore.ListenerRegistration
import com.example.ictusapp.ui.screens.common.TurnChip

@Composable
fun NursingHomeScreen(navController: NavHostController) {

    val repo = CaseRepository()

    var cases by remember { mutableStateOf<List<CaseItem>>(emptyList()) }
    var error by remember { mutableStateOf<String?>(null) }
    var reg by remember { mutableStateOf<ListenerRegistration?>(null) }

    DisposableEffect(Unit) {
        reg = repo.listenActiveCasesForRole(
            role = CaseRepository.ROLE_NURSING,
            onUpdate = { cases = it },
            onErr = { error = it }
        )
        onDispose { reg?.remove() }
    }

    NursingLayout(
        title = "Enfermería - Monitorización",
        navController = navController,
        currentRoute = Routes.NursingHome
    ) { modifier ->

        Column(
            modifier = modifier.fillMaxSize()
        ) {

            // ❌ Error
            error?.let {
                Text(
                    it,
                    color = MaterialTheme.colorScheme.error,
                    modifier = Modifier.padding(16.dp)
                )
            }

            // 📊 RESUMEN (MUY IMPORTANTE PARA TFG)
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                elevation = CardDefaults.cardElevation(4.dp)
            ) {
                Column(Modifier.padding(16.dp)) {
                    Text("🩺 Monitorización activa", style = MaterialTheme.typography.titleMedium)
                    Text("Pacientes en seguimiento: ${cases.size}")
                }
            }

            // 📋 Lista de casos
            LazyColumn(
                contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp)
            ) {
                items(items = cases, key = { it.id }) { c ->

                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 12.dp),
                        elevation = CardDefaults.cardElevation(4.dp),
                        onClick = {
                            navController.navigate(
                                Routes.NursingCaseTasks + "/${c.id}"
                            )
                        }
                    ) {
                        Column(Modifier.padding(16.dp)) {

                            Text(
                                text = c.patientName.ifBlank { "Paciente sin nombre" },
                                style = MaterialTheme.typography.titleMedium
                            )

                            Text("ID: ${c.patientId}")

                            Spacer(modifier = Modifier.height(8.dp))

                            // 🩺 Indicador clínico (simulado por ahora)
                            Text(
                                text = "🟢 Estable",
                                style = MaterialTheme.typography.bodySmall
                            )

                            Spacer(modifier = Modifier.height(8.dp))

                            // 🔁 Turno
                            TurnChip(
                                caseId = c.id,
                                role = CaseRepository.ROLE_NURSING
                            )
                        }
                    }
                }
            }
        }
    }
}