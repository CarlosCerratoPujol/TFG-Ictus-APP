package com.example.ictusapp.ui.screens.admin

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.NavHostController
import com.example.ictusapp.data.AppUser
import com.example.ictusapp.data.UserRepository
import com.example.ictusapp.ui.components.AdminLayout
import com.example.ictusapp.ui.navigation.Routes
import com.google.firebase.firestore.ListenerRegistration

@Composable
fun AdminUsersScreen(navController: NavHostController) {

    val repo = UserRepository()

    var users by remember { mutableStateOf<List<AppUser>>(emptyList()) }
    var error by remember { mutableStateOf<String?>(null) }
    var reg by remember { mutableStateOf<ListenerRegistration?>(null) }

    DisposableEffect(Unit) {
        reg = repo.listenStaffUsers(
            onUpdate = { users = it },
            onErr = { error = it }
        )
        onDispose { reg?.remove() }
    }

    AdminLayout(
        title = "Usuarios del sistema",
        navController = navController,
        currentRoute = Routes.AdminUsers
    ) { modifier ->

        Column(
            modifier = modifier.fillMaxSize()
        ) {

            // ❌ Error
            error?.let {
                Text(
                    it,
                    color = MaterialTheme.colorScheme.error,
                    modifier = Modifier.padding(16.dp)
                )
            }

            // 📊 Resumen rápido (queda muy pro)
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                elevation = CardDefaults.cardElevation(4.dp)
            ) {
                Column(Modifier.padding(16.dp)) {
                    Text("👥 Gestión de usuarios", style = MaterialTheme.typography.titleMedium)
                    Text("Total: ${users.size}")
                }
            }

            // 📋 Lista
            LazyColumn(
                contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp)
            ) {
                items(items = users, key = { it.id }) { u ->

                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 12.dp),
                        elevation = CardDefaults.cardElevation(4.dp)
                    ) {
                        Column(Modifier.padding(16.dp)) {

                            Text(
                                text = u.email,
                                style = MaterialTheme.typography.titleMedium
                            )

                            Spacer(Modifier.height(4.dp))

                            Text("Rol: ${u.role}")

                            Spacer(Modifier.height(4.dp))

                            // 🟢 Estado visual
                            Text(
                                text = if (u.active) "🟢 Activo" else "🔴 Inactivo",
                                style = MaterialTheme.typography.bodySmall
                            )
                        }
                    }
                }
            }
        }
    }
}

