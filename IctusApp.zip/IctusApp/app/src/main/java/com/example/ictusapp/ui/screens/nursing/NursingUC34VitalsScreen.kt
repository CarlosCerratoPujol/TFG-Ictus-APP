package com.example.ictusapp.ui.screens.nursing

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.NavHostController
import com.example.ictusapp.data.CaseRepository
import com.example.ictusapp.ui.components.NursingLayout
import com.example.ictusapp.ui.navigation.Routes

@Composable
fun NursingUC34VitalsScreen(navController: NavHostController, caseId: String) {

    val repo = CaseRepository()

    var sbp by remember { mutableStateOf("") }
    var dbp by remember { mutableStateOf("") }
    var glucose by remember { mutableStateOf("") }

    var withinRange by remember { mutableStateOf(true) }
    var actionTaken by remember { mutableStateOf("") }

    var loading by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }

    NursingLayout(
        title = "UC3+UC4 — Constantes y manejo",
        navController = navController,
        currentRoute = Routes.NursingHome
    ) { modifier ->

        Column(
            modifier = modifier
                .fillMaxSize()
                .padding(16.dp)
        ) {

            // 🟦 CONSTANTES
            Card(modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp)) {

                    Text("🩺 Constantes vitales", style = MaterialTheme.typography.titleMedium)

                    Spacer(Modifier.height(12.dp))

                    OutlinedTextField(
                        value = sbp,
                        onValueChange = { sbp = it },
                        label = { Text("TA sistólica (SBP)") },
                        modifier = Modifier.fillMaxWidth()
                    )

                    Spacer(Modifier.height(8.dp))

                    OutlinedTextField(
                        value = dbp,
                        onValueChange = { dbp = it },
                        label = { Text("TA diastólica (DBP)") },
                        modifier = Modifier.fillMaxWidth()
                    )

                    Spacer(Modifier.height(8.dp))

                    OutlinedTextField(
                        value = glucose,
                        onValueChange = { glucose = it },
                        label = { Text("Glucemia (mg/dL)") },
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }

            Spacer(Modifier.height(16.dp))

            // 🟦 VALORACIÓN
            Card(modifier = Modifier.fillMaxWidth()) {
                Row(
                    Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("Dentro de rango")
                    Switch(
                        checked = withinRange,
                        onCheckedChange = { withinRange = it }
                    )
                }
            }

            Spacer(Modifier.height(16.dp))

            // 🟦 MANEJO
            Card(modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp)) {

                    Text("⚕️ Actuación clínica", style = MaterialTheme.typography.titleMedium)

                    Spacer(Modifier.height(12.dp))

                    OutlinedTextField(
                        value = actionTaken,
                        onValueChange = { actionTaken = it },
                        label = { Text("Acciones realizadas") },
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }

            Spacer(Modifier.height(16.dp))

            error?.let {
                Text(it, color = MaterialTheme.colorScheme.error)
            }

            Spacer(Modifier.height(16.dp))

            // 🚀 BOTÓN
            Button(
                onClick = {
                    val s = sbp.toIntOrNull()
                    val d = dbp.toIntOrNull()
                    val g = glucose.toIntOrNull()

                    if (s == null || d == null || g == null) {
                        error = "Valores inválidos"
                        return@Button
                    }

                    loading = true
                    error = null

                    repo.completeTask(
                        caseId = caseId,
                        taskCode = "UC3_4",
                        data = mapOf(
                            "sbp" to s,
                            "dbp" to d,
                            "glucose" to g,
                            "withinRange" to withinRange,
                            "actionTaken" to actionTaken.trim()
                        ),
                        onOk = {
                            loading = false
                            navController.popBackStack()
                        },
                        onErr = {
                            loading = false
                            error = it
                        }
                    )
                },
                enabled = !loading,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(if (loading) "Guardando..." else "Guardar constantes")
            }
        }
    }
}
