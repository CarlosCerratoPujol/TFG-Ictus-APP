package com.example.ictusapp.ui.screens.common

import androidx.compose.material3.AssistChip
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import com.example.ictusapp.data.CaseRepository

@Composable
fun TurnChip(caseId: String, role: String) {
    val repo = remember { CaseRepository() }

    var hasTurn by remember { mutableStateOf(false) }
    var nextCode by remember { mutableStateOf<String?>(null) }

    DisposableEffect(caseId, role) {
        val reg = repo.listenTurnForRole(
            caseId = caseId,
            role = role,
            onUpdate = { turn: Boolean, next: String? ->
                hasTurn = turn
                nextCode = next
            },
            onErr = { _: String -> }
        )
        onDispose { reg.remove() }
    }

    if (hasTurn) {
        AssistChip(
            onClick = {},
            label = { Text("🆕 Nueva tarea ${nextCode ?: ""}") }
        )
    } else {
        AssistChip(
            onClick = {},
            label = { Text("— No hay tareas") }
        )
    }
}
